/**
 * Main App Component
 * H2_Plant_Metamodel Instance Editor
 */

import { useState, useEffect, useRef, useCallback } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import {
  Braces, FileCode2, FolderOpen, Pause, Play, RotateCcw, RotateCw, SkipForward, Trash2,
} from 'lucide-react';
import { InstanceCanvas } from './components/InstanceCanvas';
import { ClassPalette } from './components/ClassPalette';
import { Button } from './components/ui/button';
import { DIAGRAM_STYLE, DOMAIN_CLASSES } from './types/models';
import type { BaseInstance, ExportJsonResponse } from './types/models';
import * as api from './api/instances';
import * as runtimeApi from './api/runtime';

const queryClient = new QueryClient();

/** Apply the configured theme to the document root. 'auto' follows the OS. */
function useDiagramTheme() {
  useEffect(() => {
    const theme = DIAGRAM_STYLE.theme;
    if (!theme) return;
    const root = document.documentElement;
    const apply = (dark: boolean) => root.classList.toggle('dark', dark);
    if (theme === 'dark') {
      apply(true);
      return () => apply(false);
    }
    if (theme === 'light') {
      apply(false);
      return undefined;
    }
    // 'auto': watch prefers-color-scheme and react to changes.
    const media = window.matchMedia('(prefers-color-scheme: dark)');
    apply(media.matches);
    const onChange = (e: MediaQueryListEvent) => apply(e.matches);
    media.addEventListener('change', onChange);
    return () => {
      media.removeEventListener('change', onChange);
      apply(false);
    };
  }, []);
}

function AppContent() {
  useDiagramTheme();
  const [instances, setInstances] = useState<BaseInstance[]>([]);
  const [loading, setLoading] = useState(false);
  // Hidden file input drives the Load Plant flow.
  const importInputRef = useRef<HTMLInputElement | null>(null);

  // --- Scheduler state ---
  const [running, setRunning] = useState(false);
  const [tickCount, setTickCount] = useState(0);
  const [dt, setDt] = useState(1.0);

  const loadInstances = async () => {
    setLoading(true);
    try {
      const data = await api.getAllInstances();
      setInstances(data);
    } catch (error) {
      console.error('Failed to load instances:', error);
    } finally {
      setLoading(false);
    }
  };

  // Poll scheduler state once on mount; then deltas keep it fresh.
  useEffect(() => {
    loadInstances();
    runtimeApi.getState().then((s) => {
      setRunning(s.running);
      setTickCount(s.tick_count);
      setDt(s.dt);
    }).catch(() => {/* backend may not be ready yet */});
  }, []);

  // --- WebSocket for live attribute deltas ---
  const applyDeltas = useCallback(
    (deltas: Array<{ class_name: string; instance_id: string; attribute: string; value: unknown }>) => {
      setInstances((prev) =>
        prev.map((inst) => {
          const myDeltas = deltas.filter(
            (d) => d.class_name === inst.class_name && d.instance_id === inst.id,
          );
          if (myDeltas.length === 0) return inst;
          const newAttrs = { ...inst.attributes };
          for (const d of myDeltas) newAttrs[d.attribute] = d.value;
          return { ...inst, attributes: newAttrs };
        }),
      );
    },
    [],
  );

  useEffect(() => {
    const unsub = runtimeApi.subscribeWs((msg) => {
      if (msg.heartbeat) return;
      setTickCount(msg.tick ?? 0);
      if (Array.isArray(msg.deltas) && msg.deltas.length > 0) {
        applyDeltas(msg.deltas);
      }
    });
    return unsub;
  }, [applyDeltas]);

  // --- Scheduler controls ---
  const handleRun = async () => {
    const s = await runtimeApi.run();
    setRunning(s.running);
    setTickCount(s.tick_count);
  };

  const handlePause = async () => {
    const s = await runtimeApi.pause();
    setRunning(s.running);
    setTickCount(s.tick_count);
    // Refresh instances to show final state after pause.
    await loadInstances();
  };

  const handleStep = async () => {
    const s = await runtimeApi.stepOnce();
    setTickCount(s.tick_count);
    if (Array.isArray(s.deltas) && s.deltas.length > 0) {
      applyDeltas(s.deltas);
    }
  };

  const handleReset = async () => {
    if (!confirm('Reset will pause the scheduler and clear all history. Continue?')) return;
    const s = await runtimeApi.reset();
    setRunning(s.running);
    setTickCount(s.tick_count);
    await loadInstances();
  };

  const handleDtChange = async (newDt: number) => {
    if (running) {
      alert('Pause the scheduler before changing the tick interval.');
      return;
    }
    try {
      await runtimeApi.updateDt(newDt);
      setDt(newDt);
    } catch {
      alert('Invalid dt value.');
    }
  };

  const handleInstanceUpdate = async (instance: BaseInstance) => {
    try {
      await api.updateInstance(instance.class_name, instance.id, {
        attributes: instance.attributes,
      });
      await loadInstances();
    } catch (error) {
      console.error('Failed to update instance:', error);
      alert('Failed to update instance');
    }
  };

  const handleInstanceDelete = async (className: string, instanceId: string) => {
    if (!confirm('Are you sure you want to delete this instance?')) return;
    try {
      await api.deleteInstance(className, instanceId);
      await loadInstances();
    } catch (error) {
      console.error('Failed to delete instance:', error);
      alert('Failed to delete instance');
    }
  };

  const handleLinkCreate = async (sourceId: string, targetId: string, label: string) => {
    const source = instances.find((i) => i.id === sourceId);
    const target = instances.find((i) => i.id === targetId);
    if (!source || !target) {
      alert('Invalid source or target');
      return;
    }
    try {
      await api.createLink({
        source_class: source.class_name,
        source_id: sourceId,
        target_class: target.class_name,
        target_id: targetId,
        association_name: label,
      });
      await loadInstances();
    } catch (error) {
      console.error('Failed to create link:', error);
      alert('Failed to create link');
    }
  };

  const handleInstanceCreate = async (_className: string, _position: { x: number; y: number }) => {
    await loadInstances();
  };

  const downloadBlob = (blob: Blob, filename: string) => {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleExportJson = async () => {
    try {
      const data = await api.exportAsJson();
      downloadBlob(
        new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' }),
        'instances.json'
      );
    } catch (error) {
      console.error('Failed to export JSON:', error);
      alert('Failed to export JSON');
    }
  };

  const handleExportPython = async () => {
    try {
      const code = await api.exportAsPython();
      downloadBlob(new Blob([code], { type: 'text/plain' }), 'instances.py');
    } catch (error) {
      console.error('Failed to export Python:', error);
      alert('Failed to export Python');
    }
  };

  const handleImportJsonClick = () => {
    importInputRef.current?.click();
  };

  const handleImportJsonFile = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    event.target.value = '';
    if (!file) return;
    if (!confirm('Loading a plant replaces all current instances. Continue?')) return;
    try {
      const text = await file.text();
      const data = JSON.parse(text) as ExportJsonResponse;
      const result = await api.importFromJson(data, true);
      await loadInstances();
      alert(`Loaded ${result.instances} instance(s) and ${result.links} link(s).`);
    } catch (error) {
      console.error('Failed to import JSON:', error);
      const detail = (error as { response?: { data?: { detail?: string } } })?.response?.data?.detail;
      alert(`Failed to load plant: ${detail ?? (error as Error).message}`);
    }
  };

  const handleClearAll = async () => {
    if (!confirm('Are you sure you want to clear all instances?')) return;
    try {
      await api.clearAllInstances();
      await loadInstances();
    } catch (error) {
      console.error('Failed to clear instances:', error);
      alert('Failed to clear instances');
    }
  };

  const instanceCount = instances.length;

  return (
    <div className="flex h-screen flex-col bg-background">
      <header className="flex items-center justify-between gap-4 border-b border-border/60 bg-card/80 px-6 py-3 backdrop-blur-sm">
        <div className="flex min-w-0 items-center gap-3">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br from-primary to-primary/70 text-base font-bold text-primary-foreground shadow-sm">H</div>
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <h1 className="truncate font-sans text-base font-bold leading-tight text-foreground">H2_Plant_Metamodel</h1>

              <span
                className="inline-flex h-5 min-w-[1.5rem] items-center justify-center rounded-full bg-muted px-2 text-[10px] font-semibold tabular-nums text-muted-foreground"
                title={`${instanceCount} instance${instanceCount === 1 ? '' : 's'}`}
              >
                {instanceCount}
              </span>
            </div>
            <p className="text-[11px] leading-tight text-muted-foreground">
              Instance editor
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1">
          {/* Refresh */}
          <Button
            variant="ghost"
            size="icon"
            onClick={loadInstances}
            disabled={loading}
            title="Refresh"
            aria-label="Refresh"
            className="text-muted-foreground hover:text-foreground"
          >
            <RotateCw className={loading ? 'animate-spin' : ''} />
          </Button>

          <span className="mx-1 h-6 w-px bg-border" aria-hidden />

          {/* ── Simulation controls ── */}
          <div className="flex items-center gap-1 rounded-lg border border-border/60 bg-muted/30 px-2 py-0.5">
            {running ? (
              <Button
                variant="ghost"
                size="sm"
                onClick={handlePause}
                title="Pause simulation"
                className="gap-1.5 text-amber-600 hover:text-amber-700"
              >
                <Pause className="size-4" />
                <span>Pause</span>
              </Button>
            ) : (
              <Button
                variant="ghost"
                size="sm"
                onClick={handleRun}
                title="Run simulation"
                className="gap-1.5 text-emerald-600 hover:text-emerald-700"
              >
                <Play className="size-4" />
                <span>Run</span>
              </Button>
            )}
            <Button
              variant="ghost"
              size="icon"
              onClick={handleStep}
              disabled={running}
              title="Step — advance one tick"
              className="text-muted-foreground hover:text-foreground"
            >
              <SkipForward className="size-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={handleReset}
              disabled={running}
              title="Reset — pause and clear history"
              className="text-muted-foreground hover:text-destructive"
            >
              <RotateCcw className="size-4" />
            </Button>
            {/* Tick counter */}
            <span className="ml-1 min-w-[3rem] text-right text-[11px] tabular-nums text-muted-foreground">
              t={tickCount}
            </span>
            {/* dt control */}
            <label className="ml-2 flex items-center gap-1 text-[11px] text-muted-foreground">
              dt=
              <input
                type="number"
                value={dt}
                min={0.1}
                step={0.5}
                className="w-14 rounded border border-border bg-background px-1 text-right text-[11px]"
                onChange={(e) => {
                  const v = parseFloat(e.target.value);
                  if (!isNaN(v) && v > 0) handleDtChange(v);
                }}
                disabled={running}
                title="Tick interval (simulated seconds)"
              />
              s
            </label>
          </div>

          <span className="mx-1 h-6 w-px bg-border" aria-hidden />

          {/* Load / Export */}
          <Button
            variant="outline"
            size="sm"
            onClick={handleImportJsonClick}
            title="Load a previously saved plant (JSON)"
            className="gap-1.5"
          >
            <FolderOpen className="text-primary/80" />
            <span>Load</span>
          </Button>
          <input
            ref={importInputRef}
            type="file"
            accept="application/json,.json"
            className="hidden"
            onChange={handleImportJsonFile}
          />
          <Button
            variant="outline"
            size="sm"
            onClick={handleExportJson}
            title="Download instances as JSON"
            className="gap-1.5"
          >
            <Braces className="text-primary/80" />
            <span>JSON</span>
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={handleExportPython}
            title="Download instances as Python"
            className="gap-1.5"
          >
            <FileCode2 className="text-primary/80" />
            <span>Python</span>
          </Button>

          <span className="mx-1 h-6 w-px bg-border" aria-hidden />

          <Button
            variant="ghost"
            size="icon"
            onClick={handleClearAll}
            title="Clear all instances"
            aria-label="Clear all instances"
            className="text-muted-foreground hover:bg-destructive/10 hover:text-destructive"
          >
            <Trash2 />
          </Button>
        </div>
      </header>

      <main className="flex flex-1 overflow-hidden">
        <ClassPalette classes={DOMAIN_CLASSES} onInstanceCreated={loadInstances} />
        <InstanceCanvas
          instances={instances}
          availableClasses={DOMAIN_CLASSES}
          onInstanceUpdate={handleInstanceUpdate}
          onInstanceDelete={handleInstanceDelete}
          onLinkCreate={handleLinkCreate}
          onInstanceCreate={handleInstanceCreate}
        />
      </main>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AppContent />
    </QueryClientProvider>
  );
}

export default App;
