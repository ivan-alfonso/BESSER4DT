﻿/**
 * InstanceNode Component
 * Visual representation of a domain model instance with optional SVG icon.
 * Consumes the per-class style overrides exposed via classMetadata.style.
 */

import React from 'react';
import { Handle, NodeResizer, Position, type Node, type NodeProps } from '@xyflow/react';
import { Pencil, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { AddPortPopover } from './AddPortPopover';
import { AddAssociationPopover } from './AddAssociationPopover';
import { cn } from '@/lib/utils';
import type { AssociationMetadata, BaseInstance, ClassMetadata, NodeStyle, PortSideName } from '../types/models';
import { PORT_CLASSES, isPortClass } from '../types/models';

export type InstanceNodeData = {
  instance: BaseInstance;
  classMetadata: ClassMetadata;
  /** Port-class child instances anchored on this node. Each becomes an xyflow
   *  Handle whose id is the port instance's UUID â€” connection-class edges bind
   *  to those handles. */
  ports?: BaseInstance[];
  onEdit: () => void;
  onDelete: () => void;
  onPortClick?: (port: BaseInstance) => void;
  /** Invoked when the user picks (or auto-picks) a port-class to spawn from
   *  the "+" affordance. The canvas then creates the port instance, links
   *  it to this equipment via the chosen association, and opens the property
   *  editor on the new port. */
  onAddPort?: (portClassName: string, associationName: string) => void;
  /** Existing instances that match the target type of an outgoing association
   *  on this node â€” used to populate the AddAssociationPopover candidate list. */
  candidatesFor?: (assoc: AssociationMetadata) => BaseInstance[];
  /** Link an existing target instance via the chosen association. */
  onPickAssociationTarget?: (assoc: AssociationMetadata, target: BaseInstance) => void;
  /** Spawn a new target instance via the chosen association â€” opens the
   *  create-instance modal at the canvas level with the back-link pre-bound. */
  onCreateAssociationTarget?: (assoc: AssociationMetadata) => void;
};

export type InstanceNodeType = Node<InstanceNodeData, 'instance'>;

const HANDLE_POSITIONS: Array<{
  id: string;
  position: Position;
  offset: React.CSSProperties;
}> = [
  { id: 'top', position: Position.Top, offset: { top: -10 } },
  { id: 'right', position: Position.Right, offset: { right: -10 } },
  { id: 'bottom', position: Position.Bottom, offset: { bottom: -10 } },
  { id: 'left', position: Position.Left, offset: { left: -10 } },
];

/** Translate a NodeStyle to inline CSS the box / container variant can spread. */
function nodeBoxStyle(style?: NodeStyle): React.CSSProperties {
  if (!style) return {};
  const css: React.CSSProperties = {};
  if (style.fillColor) css.backgroundColor = style.fillColor;
  if (style.borderColor) css.borderColor = style.borderColor;
  if (style.borderWidth !== undefined) css.borderWidth = style.borderWidth;
  if (style.borderStyle) css.borderStyle = style.borderStyle;
  if (style.borderRadius !== undefined) css.borderRadius = style.borderRadius;
  if (style.fontSize !== undefined) css.fontSize = style.fontSize;
  if (style.fontWeight) css.fontWeight = style.fontWeight;
  if (style.fontColor) css.color = style.fontColor;
  return css;
}

/** Background for non-rectangular shapes. Renders an absolutely-positioned SVG
 * behind the node label so handles and label keep working unchanged. */
const ShapeBackground: React.FC<{
  shape: NodeStyle['shape'];
  fill: string;
  stroke: string;
  strokeWidth: number;
  strokeDasharray?: string;
}> = ({ shape, fill, stroke, strokeWidth, strokeDasharray }) => {
  const common = { fill, stroke, strokeWidth, strokeDasharray };
  if (shape === 'ellipse') {
    return (
      <svg
        className="absolute inset-0 h-full w-full"
        preserveAspectRatio="none"
        viewBox="0 0 100 100"
      >
        <ellipse cx="50" cy="50" rx="48" ry="48" {...common} />
      </svg>
    );
  }
  if (shape === 'diamond') {
    return (
      <svg
        className="absolute inset-0 h-full w-full"
        preserveAspectRatio="none"
        viewBox="0 0 100 100"
      >
        <polygon points="50,2 98,50 50,98 2,50" {...common} />
      </svg>
    );
  }
  if (shape === 'hexagon') {
    return (
      <svg
        className="absolute inset-0 h-full w-full"
        preserveAspectRatio="none"
        viewBox="0 0 100 100"
      >
        <polygon points="25,2 75,2 98,50 75,98 25,98 2,50" {...common} />
      </svg>
    );
  }
  return null;
};

const DASH_FOR_LINE: Record<string, string | undefined> = {
  solid: undefined,
  dashed: '8 4',
  dotted: '2 4',
};

const SIDE_TO_POSITION: Record<Exclude<PortSideName, 'auto'>, Position> = {
  top: Position.Top,
  right: Position.Right,
  bottom: Position.Bottom,
  left: Position.Left,
};

/** Decide which side a port handle anchors on. Order of precedence:
 *   1. PORT_CLASSES[port.class_name].portSide (if not 'auto')
 *   2. port.attributes.direction ('Inlet' â†’ Left, 'Outlet' â†’ Right)
 *   3. fallback: Left
 */
function resolvePortSide(port: BaseInstance): Position {
  const meta = PORT_CLASSES[port.class_name];
  const configured = meta?.portSide;
  if (configured && configured !== 'auto') {
    return SIDE_TO_POSITION[configured];
  }
  const direction = String(port.attributes?.direction ?? '').toLowerCase();
  if (direction === 'inlet' || direction === 'in') return Position.Left;
  if (direction === 'outlet' || direction === 'out') return Position.Right;
  return Position.Left;
}

/** Render a row of xyflow Handles for the equipment's port-class children.
 *  Each handle's id equals the port instance UUID so connection-class edges
 *  can target them via sourceHandle / targetHandle. */
const PortHandles: React.FC<{
  ports: BaseInstance[];
  onPortClick?: (port: BaseInstance) => void;
}> = ({ ports, onPortClick }) => {
  // Group by side so we can space them evenly on each face.
  const bySide: Record<Position, BaseInstance[]> = {
    [Position.Top]: [],
    [Position.Right]: [],
    [Position.Bottom]: [],
    [Position.Left]: [],
  };
  for (const port of ports) {
    bySide[resolvePortSide(port)].push(port);
  }
  return (
    <>
      {(Object.entries(bySide) as Array<[Position, BaseInstance[]]>).flatMap(([side, list]) =>
        list.map((port, i) => {
          const ratio = (i + 1) / (list.length + 1);
          const css: React.CSSProperties = {};
          if (side === Position.Top || side === Position.Bottom) {
            css.left = `${ratio * 100}%`;
          } else {
            css.top = `${ratio * 100}%`;
          }
          return (
            <Handle
              key={port.id}
              id={port.id}
              type="source"
              position={side as Position}
              style={css}
              onClick={(e) => {
                e.stopPropagation();
                onPortClick?.(port);
              }}
              title={`${port.class_name}: ${port.instance_name}`}
              // No scale-on-hover transform: it shifts the click target by a
              // few pixels right when the user is trying to drop a connection,
              // which makes port-to-port linking flaky. Color hover stays.
              className="!h-3.5 !w-3.5 !rounded-[2px] !border !border-foreground/70 !bg-foreground/85 shadow-sm hover:!bg-primary"
            />
          );
        }),
      )}
    </>
  );
};

export const InstanceNode: React.FC<NodeProps<InstanceNodeType>> = ({ data, selected }) => {
  const {
    instance,
    classMetadata,
    onEdit,
    onDelete,
    ports,
    onPortClick,
    onAddPort,
    candidatesFor,
    onPickAssociationTarget,
    onCreateAssociationTarget,
  } = data;
  const [isHovered, setIsHovered] = React.useState(false);
  const portList = ports ?? [];
  const addable = classMetadata.addablePortClasses ?? [];
  // All classes get side handles (top/right/bottom/left) so regular association
  // edges always have anchor points. Port-host classes also keep their port
  // handles — both coexist. Explicit ``connectionPoints`` overrides the default
  // (`[]` to force-hide all, or a specific subset of sides).
  const allowedSides = classMetadata.connectionPoints;
  const handlePositions = allowedSides === undefined
    ? HANDLE_POSITIONS
    : HANDLE_POSITIONS.filter((h) => allowedSides.includes(h.id as 'top' | 'right' | 'bottom' | 'left'));

  // Associations the user can create from the "â†”" affordance. Filters out
  // links already covered by other UI: container nesting, port spawning ("+"),
  // and connection-class endpoints (handled at port-handle level).
  const associationOptions: AssociationMetadata[] = React.useMemo(
    () =>
      classMetadata.associations.filter((a) => {
        if (a.isContainerAssociation) return false;
        if (a.isSourceEndpoint || a.isTargetEndpoint) return false;
        if (isPortClass(a.targetClass)) return false;
        return true;
      }),
    [classMetadata.associations],
  );
  const canAddAssociation =
    associationOptions.length > 0 &&
    !!candidatesFor &&
    !!onPickAssociationTarget &&
    !!onCreateAssociationTarget;
  const hasIcon = Boolean(classMetadata.icon) && classMetadata.useIcon !== false;
  const isContainer = Boolean(classMetadata.isContainer);
  const isResizable = Boolean(classMetadata.isResizable);
  const style = classMetadata.style;
  const shape = style?.shape;
  const labelPosition = style?.labelPosition; // top | bottom | inside
  const inlineStyle = nodeBoxStyle(style);

  // Container variant: a big rounded drop-zone with a header bar. Children land
  // inside via xyflow's parentId subflow mechanism.
  if (isContainer) {
    const size = classMetadata.defaultSize ?? { width: 320, height: 240 };
    return (
      <div
        className={cn(
          'group relative h-full w-full rounded-xl border-2 border-dashed border-primary/60 bg-primary/5 shadow-sm transition-colors',
          selected && 'border-primary ring-2 ring-ring ring-offset-2 ring-offset-background'
        )}
        style={{ minWidth: size.width, minHeight: size.height, ...inlineStyle }}
      >
        {isResizable && (
          <NodeResizer
            minWidth={Math.min(160, size.width)}
            minHeight={Math.min(120, size.height)}
            isVisible={selected}
            lineClassName="!border-primary"
            handleClassName="!h-2 !w-2 !rounded-sm !border !border-primary !bg-background"
          />
        )}
        {handlePositions.map(({ id, position, offset }) => (
          <Handle
            key={id}
            type="source"
            position={position}
            id={id}
            style={{ ...offset, zIndex: 30 }}
            className={cn('!h-3 !w-3 !border-2 !border-background !bg-primary !opacity-0 transition-all group-hover:!opacity-100 hover:!h-4 hover:!w-4 hover:!bg-primary/90', selected && '!opacity-100')}
          />
        ))}
        <PortHandles ports={portList} onPortClick={onPortClick} />
        {canAddAssociation && (
          <AddAssociationPopover
            associations={associationOptions}
            candidatesFor={candidatesFor!}
            onPickExisting={onPickAssociationTarget!}
            onCreateNew={onCreateAssociationTarget!}
            className="absolute -right-9 -top-2 z-[1100] opacity-0 transition-opacity group-hover:opacity-100"
          />
        )}
        {addable.length > 0 && onAddPort && (
          <AddPortPopover
            addable={addable}
            onAddPort={onAddPort}
            className="absolute -right-2 -top-2 z-[1100] opacity-0 transition-opacity group-hover:opacity-100"
          />
        )}
        <div className="flex items-center justify-between gap-2 rounded-t-[10px] border-b border-primary/30 bg-primary/10 px-3 py-2">
          <div className="min-w-0 flex-1">
            <div className="truncate text-xs font-semibold uppercase tracking-wider text-primary/80">
              {instance.class_name}
            </div>
            <div className="truncate text-sm font-bold text-foreground">
              {instance.instance_name}
            </div>
          </div>
          <div className="flex shrink-0 gap-1">
            <Button
              size="icon"
              variant="ghost"
              className="h-7 w-7"
              onClick={(e) => {
                e.stopPropagation();
                onEdit();
              }}
              title="Edit"
            >
              <Pencil />
            </Button>
            <Button
              size="icon"
              variant="ghost"
              className="h-7 w-7 text-destructive hover:text-destructive"
              onClick={(e) => {
                e.stopPropagation();
                onDelete();
              }}
              title="Delete"
            >
              <Trash2 />
            </Button>
          </div>
        </div>
      </div>
    );
  }

  // Non-rectangular SVG-backed shape variant (ellipse / diamond / hexagon).
  // Only meaningful when the class has no icon (icons already define a shape).
  if (!hasIcon && shape && shape !== 'rectangle' && shape !== 'rounded_rect') {
    const size = classMetadata.defaultSize ?? { width: 160, height: 100 };
    const fill = style?.fillColor ?? 'hsl(var(--card))';
    const stroke = style?.borderColor ?? 'hsl(var(--primary))';
    const strokeWidth = style?.borderWidth ?? 2;
    const dash = style?.borderStyle ? DASH_FOR_LINE[style.borderStyle] : undefined;
    return (
      <div
        className={cn(
          'group relative flex items-center justify-center text-center',
          selected && 'ring-2 ring-ring ring-offset-2 ring-offset-background'
        )}
        style={{ width: size.width, height: size.height }}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
        onClick={onEdit}
      >
        {handlePositions.map(({ id, position, offset }) => (
          <Handle
            key={id}
            type="source"
            position={position}
            id={id}
            style={{ ...offset, zIndex: 30 }}
            className={cn('!h-3 !w-3 !border-2 !border-background !bg-primary !opacity-0 transition-all group-hover:!opacity-100 hover:!h-4 hover:!w-4 hover:!bg-primary/90', selected && '!opacity-100')}
          />
        ))}
        <PortHandles ports={portList} onPortClick={onPortClick} />
        {canAddAssociation && (
          <AddAssociationPopover
            associations={associationOptions}
            candidatesFor={candidatesFor!}
            onPickExisting={onPickAssociationTarget!}
            onCreateNew={onCreateAssociationTarget!}
            className="absolute right-7 top-1 z-[1100] opacity-0 transition-opacity group-hover:opacity-100"
          />
        )}
        {addable.length > 0 && onAddPort && (
          <AddPortPopover
            addable={addable}
            onAddPort={onAddPort}
            className="absolute right-1 top-1 z-[1100] opacity-0 transition-opacity group-hover:opacity-100"
          />
        )}
        <ShapeBackground
          shape={shape}
          fill={fill}
          stroke={stroke}
          strokeWidth={strokeWidth}
          strokeDasharray={dash}
        />
        <div
          className="relative z-10 max-w-[60%] truncate px-2 text-center"
          style={{
            fontSize: style?.fontSize,
            fontWeight: style?.fontWeight ?? 'bold',
            color: style?.fontColor ?? 'hsl(var(--foreground))',
          }}
        >
          {instance.instance_name}
        </div>
      </div>
    );
  }

  return (
    <div
      className="group relative flex min-w-[100px] flex-col items-center"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* One handle per side. ConnectionMode.Loose lets source handles accept
          incoming connections too, so we don't need overlapping target handles
          (which were causing "always connects from top" because they hijacked clicks). */}
      {handlePositions.map(({ id, position, offset }) => (
        <Handle
          key={id}
          type="source"
          position={position}
          id={id}
          style={{ ...offset, zIndex: 30 }}
          className={cn('!h-3 !w-3 !border-2 !border-background !bg-primary !opacity-0 transition-all group-hover:!opacity-100 hover:!h-4 hover:!w-4 hover:!bg-primary/90', selected && '!opacity-100')}
        />
      ))}
      <PortHandles ports={portList} onPortClick={onPortClick} />
      {canAddAssociation && (
        <AddAssociationPopover
          associations={associationOptions}
          candidatesFor={candidatesFor!}
          onPickExisting={onPickAssociationTarget!}
          onCreateNew={onCreateAssociationTarget!}
          className="absolute -right-9 -top-2 z-[1100] opacity-0 transition-opacity group-hover:opacity-100"
        />
      )}
      {addable.length > 0 && onAddPort && (
        <AddPortPopover
          addable={addable}
          onAddPort={onAddPort}
          className="absolute -right-2 -top-2 z-[1100] opacity-0 transition-opacity group-hover:opacity-100"
        />
      )}

      {/* Label-on-top is opt-in via labelPosition: 'top'. The icon variant
          defaults to "bottom"; the box variant defaults to "inside". */}
      {hasIcon && labelPosition === 'top' && (
        <div className="mb-2 max-w-[140px] truncate rounded border bg-card px-2 py-1 text-center text-xs font-semibold text-foreground shadow-sm">
          {instance.instance_name}
        </div>
      )}

      {hasIcon ? (
        <button
          type="button"
          onClick={onEdit}
          className={cn(
            'relative z-10 flex h-[60px] w-[60px] items-center justify-center rounded-md text-primary transition-transform',
            isHovered && 'scale-110',
            selected && 'ring-2 ring-ring ring-offset-2 ring-offset-background'
          )}
        >
          <div
            className="flex h-full w-full items-center justify-center [&_svg]:h-full [&_svg]:w-full"
            dangerouslySetInnerHTML={{ __html: classMetadata.icon ?? '' }}
          />
        </button>
      ) : (
        <button
          type="button"
          onClick={onEdit}
          className={cn(
            'relative z-10 min-w-[160px] overflow-hidden rounded-lg border-2 border-primary bg-card text-left shadow-sm transition-shadow',
            isHovered && 'shadow-md',
            selected && 'ring-2 ring-ring ring-offset-2 ring-offset-background'
          )}
          style={inlineStyle}
        >
          {labelPosition !== 'top' && (
            <div className="class-name-chip bg-primary px-3 py-1.5 text-center text-[11px] font-semibold uppercase tracking-wider text-primary-foreground">
              {instance.class_name}
            </div>
          )}
          <div
            className="px-3 py-2 text-center text-sm font-bold text-foreground"
            style={{
              fontSize: style?.fontSize,
              fontWeight: style?.fontWeight,
              color: style?.fontColor,
            }}
          >
            {instance.instance_name}
          </div>
          <div className="space-y-1 px-3 pb-3">
            {Object.entries(instance.attributes)
              .slice(0, 2)
              .map(([key, value]) => (
                <div
                  key={key}
                  className="flex justify-between gap-2 border-t border-border pt-1 text-[10px]"
                >
                  <span className="font-semibold text-muted-foreground">{key}:</span>
                  <span className="truncate text-foreground">{String(value || 'â€”')}</span>
                </div>
              ))}
            {Object.entries(instance.attributes).length > 2 && (
              <div className="pt-1 text-center text-[10px] italic text-muted-foreground">
                +{Object.entries(instance.attributes).length - 2} more
              </div>
            )}
          </div>
        </button>
      )}

      {hasIcon && labelPosition !== 'top' && (
        <>
          <div className="mt-2 max-w-[140px] truncate rounded border bg-card px-2 py-1 text-center text-xs font-semibold text-foreground shadow-sm">
            {instance.instance_name}
          </div>
          <div className="class-name-chip mt-1 text-[9px] font-semibold uppercase tracking-wider text-primary/80">
            {instance.class_name}
          </div>
        </>
      )}

      {/* Hover popup intentionally removed: the right-side inspector
          panel is now the canonical place to see attributes + run
          methods. Hover styling (scale, shadow) still gives visual
          feedback without obscuring the canvas. */}
    </div>
  );
};
