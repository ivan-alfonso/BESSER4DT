/**
 * Instance API
 * Handles all API calls related to domain model instances
 */

import { apiClient } from './client';
import type {
  BaseInstance,
  InstanceCreateRequest,
  InstanceUpdateRequest,
  LinkCreateRequest,
  ExportJsonResponse,
  Position,
} from '../types/models';

/**
 * Create a new instance
 */
export const createInstance = async (data: InstanceCreateRequest): Promise<BaseInstance> => {
  const response = await apiClient.post<BaseInstance>('/instances/', data);
  return response.data;
};

/**
 * Get all instances
 */
export const getAllInstances = async (): Promise<BaseInstance[]> => {
  const response = await apiClient.get<BaseInstance[]>('/instances/');
  return response.data;
};

/**
 * Get instances by class name
 */
export const getInstancesByClass = async (className: string): Promise<BaseInstance[]> => {
  const response = await apiClient.get<BaseInstance[]>(`/instances/${className}`);
  return response.data;
};

/**
 * Get a specific instance
 */
export const getInstance = async (className: string, instanceId: string): Promise<BaseInstance> => {
  const response = await apiClient.get<BaseInstance>(`/instances/${className}/${instanceId}`);
  return response.data;
};

/**
 * Update an instance
 */
export const updateInstance = async (
  className: string,
  instanceId: string,
  data: InstanceUpdateRequest
): Promise<BaseInstance> => {
  const response = await apiClient.put<BaseInstance>(
    `/instances/${className}/${instanceId}`,
    data
  );
  return response.data;
};

/**
 * Delete an instance
 */
export const deleteInstance = async (className: string, instanceId: string): Promise<void> => {
  await apiClient.delete(`/instances/${className}/${instanceId}`);
};

/**
 * Update an instance's canvas position. Called on node drag-end so the
 * backend store stays in sync with the canvas layout — keeps positions
 * stable across page refresh and through save/load round-trips.
 */
export const updateInstancePosition = async (
  className: string,
  instanceId: string,
  position: Position,
): Promise<BaseInstance> => {
  const response = await apiClient.patch<BaseInstance>(
    `/instances/${className}/${instanceId}/position`,
    position,
  );
  return response.data;
};

/**
 * Runtime kernel — invoke a method on an instance.
 *
 * General: any method, any args. Use this from per-method ▶ buttons in
 * the property editor. The scheduler-shaped ``tickInstance`` below is a
 * thin convenience for ``step(dt)`` and exists mainly for the upcoming
 * periodic Run/Pause flow.
 */
export interface InvokeResponse {
  instance_id: string;
  class_name: string;
  method_name: string;
  args: Record<string, unknown>;
  result: unknown;
  instance: BaseInstance;
}

export const invokeMethod = async (
  className: string,
  instanceId: string,
  methodName: string,
  args: Record<string, unknown> = {},
): Promise<InvokeResponse> => {
  const response = await apiClient.post<InvokeResponse>('/runtime/invoke', {
    class_name: className,
    instance_id: instanceId,
    method_name: methodName,
    args,
  });
  return response.data;
};

/** Convenience: invoke ``step(dt=...)``. Used by the periodic scheduler. */
export const tickInstance = async (
  className: string,
  instanceId: string,
  dt: number = 1.0,
): Promise<InvokeResponse> => {
  const response = await apiClient.post<InvokeResponse>('/runtime/tick', {
    class_name: className,
    instance_id: instanceId,
    dt,
  });
  return response.data;
};

/**
 * Create a link between instances
 */
export const createLink = async (data: LinkCreateRequest): Promise<void> => {
  await apiClient.post('/instances/links', data);
};

/**
 * Delete a link between instances
 */
export const deleteLink = async (
  sourceClass: string,
  sourceId: string,
  targetClass: string,
  targetId: string,
  associationName: string
): Promise<void> => {
  await apiClient.delete('/instances/links', {
    params: {
      source_class: sourceClass,
      source_id: sourceId,
      target_class: targetClass,
      target_id: targetId,
      association_name: associationName,
    },
  });
};

/**
 * Clear all instances
 */
export const clearAllInstances = async (): Promise<void> => {
  await apiClient.delete('/instances/');
};

/**
 * Export instances as JSON
 */
export const exportAsJson = async (): Promise<ExportJsonResponse> => {
  const response = await apiClient.get<ExportJsonResponse>('/export/json');
  return response.data;
};

/**
 * Export instances as Python code
 */
export const exportAsPython = async (): Promise<string> => {
  const response = await apiClient.get<string>('/export/python');
  return response.data;
};

/**
 * Export instances as BUML code
 */
export const exportAsBuml = async (): Promise<string> => {
  const response = await apiClient.get<string>('/export/buml');
  return response.data;
};

/**
 * Import a previously exported JSON payload back into the live store.
 * Replaces existing instances when ``replace`` is true (default).
 */
export const importFromJson = async (
  data: ExportJsonResponse,
  replace: boolean = true,
): Promise<{ success: boolean; instances: number; links: number }> => {
  const response = await apiClient.post<{ success: boolean; instances: number; links: number }>(
    '/export/import/json',
    data,
    { params: { replace } },
  );
  return response.data;
};