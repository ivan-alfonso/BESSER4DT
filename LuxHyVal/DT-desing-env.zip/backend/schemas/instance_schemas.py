"""
Pydantic Schemas for Instance API

Defines request and response models for the REST API.
"""

from pydantic import BaseModel, Field
from typing import Dict, List, Any, Optional
from datetime import date, time, datetime


class Position(BaseModel):
    """Canvas position for an instance node. Persisted on the backend so
    layouts survive page refresh and round-trip through save/load."""
    x: float
    y: float


class InstanceCreate(BaseModel):
    """Schema for creating a new instance."""
    class_name: str = Field(..., description="Name of the class to instantiate")
    instance_name: str = Field(..., description="Name/identifier for the instance")
    attributes: Dict[str, Any] = Field(default_factory=dict, description="Attribute values")
    position: Optional[Position] = Field(default=None, description="Initial canvas position")

    model_config = {
        "json_schema_extra": {
            "example": {
                "class_name": "Book",
                "instance_name": "book1",
                "attributes": {
                    "title": "The Great Gatsby",
                    "pages": 180
                },
                "position": {"x": 240, "y": 120}
            }
        }
    }


class InstanceUpdate(BaseModel):
    """Schema for updating an existing instance."""
    attributes: Dict[str, Any] = Field(..., description="Attribute values to update")

    model_config = {
        "json_schema_extra": {
            "example": {
                "attributes": {
                    "title": "Updated Title",
                    "pages": 200
                }
            }
        }
    }


class LinkData(BaseModel):
    """Schema for a link in an instance response."""
    association_name: str
    target_class: str
    target_id: str


class InstanceResponse(BaseModel):
    """Schema for instance response."""
    id: str = Field(..., description="Unique instance ID")
    class_name: str = Field(..., description="Name of the class")
    instance_name: str = Field(..., description="Name/identifier of the instance")
    attributes: Dict[str, Any] = Field(default_factory=dict, description="Attribute values")
    links: List[LinkData] = Field(default_factory=list, description="Association links")
    position: Optional[Position] = Field(default=None, description="Canvas position")

    model_config = {
        "json_schema_extra": {
            "example": {
                "id": "123e4567-e89b-12d3-a456-426614174000",
                "class_name": "Book",
                "instance_name": "book1",
                "attributes": {
                    "title": "The Great Gatsby",
                    "pages": 180
                },
                "links": [],
                "position": {"x": 240, "y": 120}
            }
        }
    }


class LinkCreate(BaseModel):
    """Schema for creating a link between instances."""
    source_class: str = Field(..., description="Source instance class name")
    source_id: str = Field(..., description="Source instance ID")
    target_class: str = Field(..., description="Target instance class name")
    target_id: str = Field(..., description="Target instance ID")
    association_name: str = Field(..., description="Name of the association/relationship")
    
    model_config = {
        "json_schema_extra": {
            "example": {
                "source_class": "Library",
                "source_id": "123e4567-e89b-12d3-a456-426614174000",
                "target_class": "Book",
                "target_id": "456e7890-e89b-12d3-a456-426614174111",
                "association_name": "books"
            }
        }
    }


class PortSchema(BaseModel):
    """Pydantic schema for Port class."""
    direction: Optional[Any] = None
    designPressure: Optional[float] = None
    name: Optional[str] = None
    designTemperature: Optional[float] = None
    
    model_config = {
        "json_schema_extra": {
            "example": {
                "direction": None,                "designPressure": 0.0,                "name": "example value",                "designTemperature": 0.0            }
        }
    }

class StreamSchema(BaseModel):
    """Pydantic schema for Stream class."""
    tag: Optional[str] = None
    name: Optional[str] = None
    
    model_config = {
        "json_schema_extra": {
            "example": {
                "tag": "example value",                "name": "example value"            }
        }
    }

class EnergyStreamSchema(BaseModel):
    """Pydantic schema for EnergyStream class."""
    energyType: Optional[str] = None
    frequency: Optional[float] = None
    name: Optional[str] = None
    voltage: Optional[float] = None
    power: Optional[float] = None
    tag: Optional[str] = None
    
    model_config = {
        "json_schema_extra": {
            "example": {
                "energyType": "example value",                "frequency": 0.0,                "name": "example value",                "voltage": 0.0,                "power": 0.0,                "tag": "example value"            }
        }
    }

class MaterialStreamSchema(BaseModel):
    """Pydantic schema for MaterialStream class."""
    temperature: Optional[float] = None
    enthalpy: Optional[float] = None
    name: Optional[str] = None
    phase: Optional[Any] = None
    massFlow: Optional[float] = None
    density: Optional[float] = None
    tag: Optional[str] = None
    pressure: Optional[float] = None
    vaporFraction: Optional[float] = None
    molarFlow: Optional[float] = None
    
    model_config = {
        "json_schema_extra": {
            "example": {
                "temperature": 0.0,                "enthalpy": 0.0,                "name": "example value",                "phase": None,                "massFlow": 0.0,                "density": 0.0,                "tag": "example value",                "pressure": 0.0,                "vaporFraction": 0.0,                "molarFlow": 0.0            }
        }
    }

class EquipmentSchema(BaseModel):
    """Pydantic schema for Equipment class."""
    name: Optional[str] = None
    status: Optional[Any] = None
    manufacturer: Optional[str] = None
    tag: Optional[str] = None
    modelNumber: Optional[str] = None
    installationDate: Optional[date] = None
    
    model_config = {
        "json_schema_extra": {
            "example": {
                "name": "example value",                "status": None,                "manufacturer": "example value",                "tag": "example value",                "modelNumber": "example value",                "installationDate": None            }
        }
    }

class TransportUnitSchema(BaseModel):
    """Pydantic schema for TransportUnit class."""
    attribute: Optional[str] = None
    name: Optional[str] = None
    status: Optional[Any] = None
    manufacturer: Optional[str] = None
    tag: Optional[str] = None
    modelNumber: Optional[str] = None
    installationDate: Optional[date] = None
    
    model_config = {
        "json_schema_extra": {
            "example": {
                "attribute": "example value",                "name": "example value",                "status": None,                "manufacturer": "example value",                "tag": "example value",                "modelNumber": "example value",                "installationDate": None            }
        }
    }

class TruckSchema(BaseModel):
    """Pydantic schema for Truck class."""
    attribute: Optional[str] = None
    status: Optional[Any] = None
    manufacturer: Optional[str] = None
    name: Optional[str] = None
    tag: Optional[str] = None
    currentLoad: Optional[float] = None
    modelNumber: Optional[str] = None
    capacity: Optional[float] = None
    installationDate: Optional[date] = None
    
    model_config = {
        "json_schema_extra": {
            "example": {
                "attribute": "example value",                "status": None,                "manufacturer": "example value",                "name": "example value",                "tag": "example value",                "currentLoad": 0.0,                "modelNumber": "example value",                "capacity": 0.0,                "installationDate": None            }
        }
    }

class H2DeliveryPointSchema(BaseModel):
    """Pydantic schema for H2DeliveryPoint class."""
    attribute: Optional[str] = None
    dispensingRate: Optional[float] = None
    status: Optional[Any] = None
    manufacturer: Optional[str] = None
    dispensingPressure: Optional[float] = None
    name: Optional[str] = None
    tag: Optional[str] = None
    modelNumber: Optional[str] = None
    tankCapacity: Optional[float] = None
    currentLevel: Optional[float] = None
    installationDate: Optional[date] = None
    
    model_config = {
        "json_schema_extra": {
            "example": {
                "attribute": "example value",                "dispensingRate": 0.0,                "status": None,                "manufacturer": "example value",                "dispensingPressure": 0.0,                "name": "example value",                "tag": "example value",                "modelNumber": "example value",                "tankCapacity": 0.0,                "currentLevel": 0.0,                "installationDate": None            }
        }
    }

class PowerSourceSchema(BaseModel):
    """Pydantic schema for PowerSource class."""
    status: Optional[Any] = None
    manufacturer: Optional[str] = None
    ratedPower: Optional[float] = None
    name: Optional[str] = None
    tag: Optional[str] = None
    modelNumber: Optional[str] = None
    availability: Optional[float] = None
    installationDate: Optional[date] = None
    
    model_config = {
        "json_schema_extra": {
            "example": {
                "status": None,                "manufacturer": "example value",                "ratedPower": 0.0,                "name": "example value",                "tag": "example value",                "modelNumber": "example value",                "availability": 0.0,                "installationDate": None            }
        }
    }

class UnitOperationSchema(BaseModel):
    """Pydantic schema for UnitOperation class."""
    name: Optional[str] = None
    status: Optional[Any] = None
    manufacturer: Optional[str] = None
    tag: Optional[str] = None
    modelNumber: Optional[str] = None
    installationDate: Optional[date] = None
    
    model_config = {
        "json_schema_extra": {
            "example": {
                "name": "example value",                "status": None,                "manufacturer": "example value",                "tag": "example value",                "modelNumber": "example value",                "installationDate": None            }
        }
    }

class ElectrolyzerSchema(BaseModel):
    """Pydantic schema for Electrolyzer class."""
    installationDate: Optional[date] = None
    operatingTemperature: Optional[float] = None
    status: Optional[Any] = None
    manufacturer: Optional[str] = None
    nominalPower: Optional[float] = None
    maxLoad: Optional[float] = None
    stackVoltage: Optional[float] = None
    operatingPressure: Optional[float] = None
    name: Optional[str] = None
    tag: Optional[str] = None
    nominalH2Production: Optional[float] = None
    modelNumber: Optional[str] = None
    stackCurrent: Optional[float] = None
    minLoad: Optional[float] = None
    specificEnergyConsumption: Optional[float] = None
    
    model_config = {
        "json_schema_extra": {
            "example": {
                "installationDate": None,                "operatingTemperature": 0.0,                "status": None,                "manufacturer": "example value",                "nominalPower": 0.0,                "maxLoad": 0.0,                "stackVoltage": 0.0,                "operatingPressure": 0.0,                "name": "example value",                "tag": "example value",                "nominalH2Production": 0.0,                "modelNumber": "example value",                "stackCurrent": 0.0,                "minLoad": 0.0,                "specificEnergyConsumption": 0.0            }
        }
    }

class SOECElectrolyzerSchema(BaseModel):
    """Pydantic schema for SOECElectrolyzer class."""
    status: Optional[Any] = None
    operatingTemperature: Optional[float] = None
    nominalPower: Optional[float] = None
    stackVoltage: Optional[float] = None
    operatingPressure: Optional[float] = None
    modelNumber: Optional[str] = None
    installationDate: Optional[date] = None
    manufacturer: Optional[str] = None
    maxLoad: Optional[float] = None
    ceramicMaterial: Optional[str] = None
    operatingTempSOEC: Optional[float] = None
    name: Optional[str] = None
    tag: Optional[str] = None
    nominalH2Production: Optional[float] = None
    stackCurrent: Optional[float] = None
    minLoad: Optional[float] = None
    specificEnergyConsumption: Optional[float] = None
    
    model_config = {
        "json_schema_extra": {
            "example": {
                "status": None,                "operatingTemperature": 0.0,                "nominalPower": 0.0,                "stackVoltage": 0.0,                "operatingPressure": 0.0,                "modelNumber": "example value",                "installationDate": None,                "manufacturer": "example value",                "maxLoad": 0.0,                "ceramicMaterial": "example value",                "operatingTempSOEC": 0.0,                "name": "example value",                "tag": "example value",                "nominalH2Production": 0.0,                "stackCurrent": 0.0,                "minLoad": 0.0,                "specificEnergyConsumption": 0.0            }
        }
    }

class AlkalineElectrolyzerSchema(BaseModel):
    """Pydantic schema for AlkalineElectrolyzer class."""
    status: Optional[Any] = None
    operatingTemperature: Optional[float] = None
    nominalPower: Optional[float] = None
    stackVoltage: Optional[float] = None
    operatingPressure: Optional[float] = None
    bubblePoint: Optional[float] = None
    modelNumber: Optional[str] = None
    electrolyteConcentration: Optional[float] = None
    installationDate: Optional[date] = None
    manufacturer: Optional[str] = None
    maxLoad: Optional[float] = None
    name: Optional[str] = None
    tag: Optional[str] = None
    nominalH2Production: Optional[float] = None
    stackCurrent: Optional[float] = None
    minLoad: Optional[float] = None
    specificEnergyConsumption: Optional[float] = None
    
    model_config = {
        "json_schema_extra": {
            "example": {
                "status": None,                "operatingTemperature": 0.0,                "nominalPower": 0.0,                "stackVoltage": 0.0,                "operatingPressure": 0.0,                "bubblePoint": 0.0,                "modelNumber": "example value",                "electrolyteConcentration": 0.0,                "installationDate": None,                "manufacturer": "example value",                "maxLoad": 0.0,                "name": "example value",                "tag": "example value",                "nominalH2Production": 0.0,                "stackCurrent": 0.0,                "minLoad": 0.0,                "specificEnergyConsumption": 0.0            }
        }
    }

class PEMElectrolyzerSchema(BaseModel):
    """Pydantic schema for PEMElectrolyzer class."""
    membraneArea: Optional[float] = None
    status: Optional[Any] = None
    operatingTemperature: Optional[float] = None
    nominalPower: Optional[float] = None
    membraneThickness: Optional[float] = None
    stackVoltage: Optional[float] = None
    operatingPressure: Optional[float] = None
    modelNumber: Optional[str] = None
    installationDate: Optional[date] = None
    manufacturer: Optional[str] = None
    maxLoad: Optional[float] = None
    name: Optional[str] = None
    tag: Optional[str] = None
    nominalH2Production: Optional[float] = None
    stackCurrent: Optional[float] = None
    minLoad: Optional[float] = None
    specificEnergyConsumption: Optional[float] = None
    
    model_config = {
        "json_schema_extra": {
            "example": {
                "membraneArea": 0.0,                "status": None,                "operatingTemperature": 0.0,                "nominalPower": 0.0,                "membraneThickness": 0.0,                "stackVoltage": 0.0,                "operatingPressure": 0.0,                "modelNumber": "example value",                "installationDate": None,                "manufacturer": "example value",                "maxLoad": 0.0,                "name": "example value",                "tag": "example value",                "nominalH2Production": 0.0,                "stackCurrent": 0.0,                "minLoad": 0.0,                "specificEnergyConsumption": 0.0            }
        }
    }

class GridConnectionSchema(BaseModel):
    """Pydantic schema for GridConnection class."""
    frequency: Optional[float] = None
    status: Optional[Any] = None
    manufacturer: Optional[str] = None
    ratedPower: Optional[float] = None
    voltage: Optional[float] = None
    maxPower: Optional[float] = None
    name: Optional[str] = None
    tag: Optional[str] = None
    modelNumber: Optional[str] = None
    availability: Optional[float] = None
    installationDate: Optional[date] = None
    
    model_config = {
        "json_schema_extra": {
            "example": {
                "frequency": 0.0,                "status": None,                "manufacturer": "example value",                "ratedPower": 0.0,                "voltage": 0.0,                "maxPower": 0.0,                "name": "example value",                "tag": "example value",                "modelNumber": "example value",                "availability": 0.0,                "installationDate": None            }
        }
    }

class WindFarmSchema(BaseModel):
    """Pydantic schema for WindFarm class."""
    ratedWindSpeed: Optional[float] = None
    status: Optional[Any] = None
    manufacturer: Optional[str] = None
    ratedPower: Optional[float] = None
    currentPower: Optional[float] = None
    turbineCount: Optional[int] = None
    hubHeight: Optional[float] = None
    name: Optional[str] = None
    tag: Optional[str] = None
    modelNumber: Optional[str] = None
    availability: Optional[float] = None
    installationDate: Optional[date] = None
    
    model_config = {
        "json_schema_extra": {
            "example": {
                "ratedWindSpeed": 0.0,                "status": None,                "manufacturer": "example value",                "ratedPower": 0.0,                "currentPower": 0.0,                "turbineCount": 0,                "hubHeight": 0.0,                "name": "example value",                "tag": "example value",                "modelNumber": "example value",                "availability": 0.0,                "installationDate": None            }
        }
    }

class SolarFarmSchema(BaseModel):
    """Pydantic schema for SolarFarm class."""
    installationDate: Optional[date] = None
    status: Optional[Any] = None
    manufacturer: Optional[str] = None
    ratedPower: Optional[float] = None
    area: Optional[float] = None
    name: Optional[str] = None
    tag: Optional[str] = None
    modelNumber: Optional[str] = None
    availability: Optional[float] = None
    panelCount: Optional[int] = None
    peakPower: Optional[float] = None
    
    model_config = {
        "json_schema_extra": {
            "example": {
                "installationDate": None,                "status": None,                "manufacturer": "example value",                "ratedPower": 0.0,                "area": 0.0,                "name": "example value",                "tag": "example value",                "modelNumber": "example value",                "availability": 0.0,                "panelCount": 0,                "peakPower": 0.0            }
        }
    }

class ValveSchema(BaseModel):
    """Pydantic schema for Valve class."""
    status: Optional[Any] = None
    manufacturer: Optional[str] = None
    valveType: Optional[str] = None
    maxPressure: Optional[float] = None
    name: Optional[str] = None
    tag: Optional[str] = None
    cv: Optional[float] = None
    modelNumber: Optional[str] = None
    opening: Optional[float] = None
    installationDate: Optional[date] = None
    
    model_config = {
        "json_schema_extra": {
            "example": {
                "status": None,                "manufacturer": "example value",                "valveType": "example value",                "maxPressure": 0.0,                "name": "example value",                "tag": "example value",                "cv": 0.0,                "modelNumber": "example value",                "opening": 0.0,                "installationDate": None            }
        }
    }

class StorageTankSchema(BaseModel):
    """Pydantic schema for StorageTank class."""
    volume: Optional[float] = None
    status: Optional[Any] = None
    manufacturer: Optional[str] = None
    currentLevel: Optional[float] = None
    maxPressure: Optional[float] = None
    level: Optional[float] = None
    material: Optional[str] = None
    storagePhase: Optional[Any] = None
    name: Optional[str] = None
    tag: Optional[str] = None
    modelNumber: Optional[str] = None
    currentPressure: Optional[float] = None
    installationDate: Optional[date] = None
    
    model_config = {
        "json_schema_extra": {
            "example": {
                "volume": 0.0,                "status": None,                "manufacturer": "example value",                "currentLevel": 0.0,                "maxPressure": 0.0,                "level": 0.0,                "material": "example value",                "storagePhase": None,                "name": "example value",                "tag": "example value",                "modelNumber": "example value",                "currentPressure": 0.0,                "installationDate": None            }
        }
    }

class SeparatorSchema(BaseModel):
    """Pydantic schema for Separator class."""
    status: Optional[Any] = None
    separationEfficiency: Optional[float] = None
    manufacturer: Optional[str] = None
    name: Optional[str] = None
    tag: Optional[str] = None
    modelNumber: Optional[str] = None
    recoveryRate: Optional[float] = None
    installationDate: Optional[date] = None
    
    model_config = {
        "json_schema_extra": {
            "example": {
                "status": None,                "separationEfficiency": 0.0,                "manufacturer": "example value",                "name": "example value",                "tag": "example value",                "modelNumber": "example value",                "recoveryRate": 0.0,                "installationDate": None            }
        }
    }

class PSAUnitSchema(BaseModel):
    """Pydantic schema for PSAUnit class."""
    adsorbentType: Optional[str] = None
    workingPressure: Optional[float] = None
    status: Optional[Any] = None
    manufacturer: Optional[str] = None
    purgeRatio: Optional[float] = None
    separationEfficiency: Optional[float] = None
    name: Optional[str] = None
    tag: Optional[str] = None
    modelNumber: Optional[str] = None
    recoveryRate: Optional[float] = None
    cycleTime: Optional[float] = None
    installationDate: Optional[date] = None
    
    model_config = {
        "json_schema_extra": {
            "example": {
                "adsorbentType": "example value",                "workingPressure": 0.0,                "status": None,                "manufacturer": "example value",                "purgeRatio": 0.0,                "separationEfficiency": 0.0,                "name": "example value",                "tag": "example value",                "modelNumber": "example value",                "recoveryRate": 0.0,                "cycleTime": 0.0,                "installationDate": None            }
        }
    }

class DryerSchema(BaseModel):
    """Pydantic schema for Dryer class."""
    moistureRemovalRate: Optional[float] = None
    status: Optional[Any] = None
    manufacturer: Optional[str] = None
    separationEfficiency: Optional[float] = None
    name: Optional[str] = None
    tag: Optional[str] = None
    modelNumber: Optional[str] = None
    recoveryRate: Optional[float] = None
    dewPoint: Optional[float] = None
    installationDate: Optional[date] = None
    
    model_config = {
        "json_schema_extra": {
            "example": {
                "moistureRemovalRate": 0.0,                "status": None,                "manufacturer": "example value",                "separationEfficiency": 0.0,                "name": "example value",                "tag": "example value",                "modelNumber": "example value",                "recoveryRate": 0.0,                "dewPoint": 0.0,                "installationDate": None            }
        }
    }

class PumpSchema(BaseModel):
    """Pydantic schema for Pump class."""
    installationDate: Optional[date] = None
    status: Optional[Any] = None
    manufacturer: Optional[str] = None
    flowRate: Optional[float] = None
    head: Optional[float] = None
    name: Optional[str] = None
    tag: Optional[str] = None
    modelNumber: Optional[str] = None
    power: Optional[float] = None
    efficiency: Optional[float] = None
    
    model_config = {
        "json_schema_extra": {
            "example": {
                "installationDate": None,                "status": None,                "manufacturer": "example value",                "flowRate": 0.0,                "head": 0.0,                "name": "example value",                "tag": "example value",                "modelNumber": "example value",                "power": 0.0,                "efficiency": 0.0            }
        }
    }

class CompressorSchema(BaseModel):
    """Pydantic schema for Compressor class."""
    inletPressure: Optional[float] = None
    stages: Optional[int] = None
    status: Optional[Any] = None
    manufacturer: Optional[str] = None
    outletPressure: Optional[float] = None
    name: Optional[str] = None
    compressionRatio: Optional[float] = None
    tag: Optional[str] = None
    power: Optional[float] = None
    modelNumber: Optional[str] = None
    isentropicEfficiency: Optional[float] = None
    installationDate: Optional[date] = None
    
    model_config = {
        "json_schema_extra": {
            "example": {
                "inletPressure": 0.0,                "stages": 0,                "status": None,                "manufacturer": "example value",                "outletPressure": 0.0,                "name": "example value",                "compressionRatio": 0.0,                "tag": "example value",                "power": 0.0,                "modelNumber": "example value",                "isentropicEfficiency": 0.0,                "installationDate": None            }
        }
    }
