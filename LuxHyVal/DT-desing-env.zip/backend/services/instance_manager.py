"""
Instance Manager Service

Manages in-memory storage and operations for domain model instances.
"""

from typing import Dict, List, Optional, Any
from uuid import uuid4
from metamodel.domain_classes import Pump, MaterialStream, AlkalineElectrolyzer, PSAUnit, Stream, WindFarm, Port, SolarFarm, EnergyStream, PEMElectrolyzer, StorageTank, Dryer, Valve, PowerSource, Separator, Compressor, GridConnection, Truck, TransportUnit, Equipment, H2DeliveryPoint, UnitOperation, Electrolyzer, SOECElectrolyzer

class InstanceManager:
    """
    Manages instances of domain model classes.
    
    This service maintains an in-memory store of all instances and provides
    CRUD operations for managing them.
    """
    
    def __init__(self):
        """Initialize the instance manager with empty storage."""
        # Storage: {class_name: {instance_id: instance_data}}
        self.instances: Dict[str, Dict[str, Dict[str, Any]]] = {            "Pump": {},            "MaterialStream": {},            "AlkalineElectrolyzer": {},            "PSAUnit": {},            "Stream": {},            "WindFarm": {},            "Port": {},            "SolarFarm": {},            "EnergyStream": {},            "PEMElectrolyzer": {},            "StorageTank": {},            "Dryer": {},            "Valve": {},            "PowerSource": {},            "Separator": {},            "Compressor": {},            "GridConnection": {},            "Truck": {},            "TransportUnit": {},            "Equipment": {},            "H2DeliveryPoint": {},            "UnitOperation": {},            "Electrolyzer": {},            "SOECElectrolyzer": {},        }
        
        # Class mapping for creating instances
        self.class_map = {            "Pump": Pump,            "MaterialStream": MaterialStream,            "AlkalineElectrolyzer": AlkalineElectrolyzer,            "PSAUnit": PSAUnit,            "Stream": Stream,            "WindFarm": WindFarm,            "Port": Port,            "SolarFarm": SolarFarm,            "EnergyStream": EnergyStream,            "PEMElectrolyzer": PEMElectrolyzer,            "StorageTank": StorageTank,            "Dryer": Dryer,            "Valve": Valve,            "PowerSource": PowerSource,            "Separator": Separator,            "Compressor": Compressor,            "GridConnection": GridConnection,            "Truck": Truck,            "TransportUnit": TransportUnit,            "Equipment": Equipment,            "H2DeliveryPoint": H2DeliveryPoint,            "UnitOperation": UnitOperation,            "Electrolyzer": Electrolyzer,            "SOECElectrolyzer": SOECElectrolyzer,        }
    
    def create_instance(
        self,
        class_name: str,
        instance_name: str,
        attributes: Dict[str, Any],
        position: Optional[Dict[str, float]] = None,
    ) -> Dict[str, Any]:
        """
        Create a new instance of a domain model class.

        Args:
            class_name: Name of the class to instantiate
            instance_name: Name/identifier for the instance
            attributes: Dictionary of attribute values
            position: Optional ``{"x": float, "y": float}`` canvas position.
                Persisting it server-side keeps the layout stable across
                page refreshes and across save/load round-trips.

        Returns:
            Dictionary representation of the created instance

        Raises:
            ValueError: If class_name is invalid
        """
        if class_name not in self.class_map:
            raise ValueError(f"Unknown class: {class_name}")

        instance_id = str(uuid4())

        instance_data = {
            "id": instance_id,
            "class_name": class_name,
            "instance_name": instance_name,
            "attributes": attributes,
            "links": [],
            "position": dict(position) if position else None,
        }

        self.instances[class_name][instance_id] = instance_data

        return instance_data
    
    def get_instance(self, class_name: str, instance_id: str) -> Optional[Dict[str, Any]]:
        """Get a specific instance by class name and ID."""
        if class_name not in self.instances:
            return None
        return self.instances[class_name].get(instance_id)
    
    def get_instances_by_class(self, class_name: str) -> Optional[List[Dict[str, Any]]]:
        """Get all instances of a specific class."""
        if class_name not in self.instances:
            return None
        return list(self.instances[class_name].values())
    
    def get_all_instances(self) -> List[Dict[str, Any]]:
        """Get all instances across all classes."""
        all_instances = []
        for class_instances in self.instances.values():
            all_instances.extend(class_instances.values())
        return all_instances
    
    def update_instance(self, class_name: str, instance_id: str, attributes: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Update an existing instance's attributes."""
        instance = self.get_instance(class_name, instance_id)
        if instance is None:
            return None

        instance["attributes"].update(attributes)
        return instance

    def update_instance_position(
        self,
        class_name: str,
        instance_id: str,
        position: Dict[str, float],
    ) -> Optional[Dict[str, Any]]:
        """Update only the canvas position. Called on node drag-end from the
        frontend so layout changes persist without a full instance update."""
        instance = self.get_instance(class_name, instance_id)
        if instance is None:
            return None
        instance["position"] = {"x": float(position["x"]), "y": float(position["y"])}
        return instance
    
    def delete_instance(self, class_name: str, instance_id: str) -> bool:
        """Delete an instance."""
        if class_name not in self.instances:
            return False
        
        if instance_id in self.instances[class_name]:
            # Remove all links involving this instance
            self._remove_instance_links(class_name, instance_id)
            del self.instances[class_name][instance_id]
            return True
        
        return False
    
    def create_link(self, source_class: str, source_id: str, target_class: str, target_id: str, association_name: str):
        """Create a link (association) between two instances."""
        source_instance = self.get_instance(source_class, source_id)
        target_instance = self.get_instance(target_class, target_id)
        
        if source_instance is None:
            raise ValueError(f"Source instance not found: {source_class}#{source_id}")
        if target_instance is None:
            raise ValueError(f"Target instance not found: {target_class}#{target_id}")
        
        link_data = {
            "association_name": association_name,
            "target_class": target_class,
            "target_id": target_id
        }
        
        if link_data not in source_instance["links"]:
            source_instance["links"].append(link_data)
    
    def delete_link(self, source_class: str, source_id: str, target_class: str, target_id: str, association_name: str):
        """Delete a link between two instances."""
        source_instance = self.get_instance(source_class, source_id)
        
        if source_instance is None:
            raise ValueError(f"Source instance not found: {source_class}#{source_id}")
        
        link_data = {
            "association_name": association_name,
            "target_class": target_class,
            "target_id": target_id
        }
        
        if link_data in source_instance["links"]:
            source_instance["links"].remove(link_data)
    
    def _remove_instance_links(self, class_name: str, instance_id: str):
        """Remove all links involving a specific instance."""
        # Remove links from other instances pointing to this one
        for cls_instances in self.instances.values():
            for instance in cls_instances.values():
                instance["links"] = [
                    link for link in instance["links"]
                    if not (link["target_class"] == class_name and link["target_id"] == instance_id)
                ]
    
    def clear_all(self):
        """Clear all instances (useful for testing/reset)."""
        for class_name in self.instances:
            self.instances[class_name].clear()

    def import_state(self, state: Dict[str, Any], replace: bool = True) -> Dict[str, int]:
        """
        Replace storage with the export-shaped payload produced by
        ``ExportService.export_to_json``.

        Payload shape:
            ``{"model_name": ..., "instances": {ClassName: [instance_data, ...]}}``

        Instance ids are preserved so that ``links`` continue to resolve.
        Validation is done up front so a typo in one class doesn't leave
        the store half-populated.

        Args:
            state: The export-shaped dictionary.
            replace: When True (default), wipe existing state first. When
                False, merge — later instances with the same id silently
                overwrite earlier ones.

        Returns:
            ``{"instances": N, "links": M}`` on success.

        Raises:
            ValueError: If the payload shape is invalid or references a
                class not defined in this platform.
        """
        if not isinstance(state, dict) or "instances" not in state:
            raise ValueError("Invalid import payload: expected a dict with an 'instances' key")

        instances_by_class = state["instances"]
        if not isinstance(instances_by_class, dict):
            raise ValueError("Invalid import payload: 'instances' must be a dict keyed by class name")

        # Validate up front so we don't half-import on a typo.
        for class_name in instances_by_class:
            if class_name not in self.class_map:
                raise ValueError(f"Unknown class in import payload: {class_name}")

        if replace:
            self.clear_all()

        instance_count = 0
        link_count = 0
        for class_name, instance_list in instances_by_class.items():
            for instance_data in instance_list:
                if not isinstance(instance_data, dict) or "id" not in instance_data:
                    raise ValueError(f"Invalid instance entry under class '{class_name}'")
                iid = instance_data["id"]
                links = list(instance_data.get("links", []))
                raw_position = instance_data.get("position")
                position = (
                    {"x": float(raw_position["x"]), "y": float(raw_position["y"])}
                    if isinstance(raw_position, dict) and "x" in raw_position and "y" in raw_position
                    else None
                )
                self.instances[class_name][iid] = {
                    "id": iid,
                    "class_name": class_name,
                    "instance_name": instance_data.get("instance_name", ""),
                    "attributes": dict(instance_data.get("attributes", {})),
                    "links": [dict(link) for link in links],
                    "position": position,
                }
                instance_count += 1
                link_count += len(links)

        return {"instances": instance_count, "links": link_count}


# Singleton instance
instance_manager = InstanceManager()