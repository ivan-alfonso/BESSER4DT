"""
Domain Model Classes for H2_Plant_Metamodel

Auto-generated Python classes representing the domain model.
These classes are used to create and manage instances.
"""

from typing import Optional, List, Set, Any
from datetime import datetime, date, time


# Domain Model Classes

class Port:
    """
    Port class from H2_Plant_Metamodel domain model.
    
    Attributes:
        direction (PortDirection): PortDirection attribute        designPressure (float): float attribute        name (str): str attribute        designTemperature (float): float attribute    """
    
    def __init__(self, direction: Optional[Any] = None, designPressure: Optional[float] = None, name: Optional[str] = None, designTemperature: Optional[float] = None):
        """Initialize Port instance."""
        self.direction = direction
        self.designPressure = designPressure
        self.name = name
        self.designTemperature = designTemperature
        
        # Association references
        self.equipment: Optional['Equipment'] = None
        self.incomingStreams: List['Stream'] = []
        self.outgoingStreams: List['Stream'] = []
    
    def to_dict(self) -> dict:
        """Convert instance to dictionary."""
        return {
            "class_name": "Port",
            "direction": self.direction,
            "designPressure": self.designPressure,
            "name": self.name,
            "designTemperature": self.designTemperature,
            "equipment": [obj.to_dict() if hasattr(obj, 'to_dict') else str(obj) for obj in (self.equipment if isinstance(self.equipment, list) else [self.equipment] if self.equipment else [])],
            "incomingStreams": [obj.to_dict() if hasattr(obj, 'to_dict') else str(obj) for obj in (self.incomingStreams if isinstance(self.incomingStreams, list) else [self.incomingStreams] if self.incomingStreams else [])],
            "outgoingStreams": [obj.to_dict() if hasattr(obj, 'to_dict') else str(obj) for obj in (self.outgoingStreams if isinstance(self.outgoingStreams, list) else [self.outgoingStreams] if self.outgoingStreams else [])],
        }

    def __repr__(self) -> str:
        return f"Port(direction={self.direction!r}, designPressure={self.designPressure!r}, name={self.name!r}, designTemperature={self.designTemperature!r})"

    # ------------------------------------------------------------------
    # User-authored behaviour
    # ------------------------------------------------------------------
    # Methods are emitted from cls.methods. Phase 1.0 only executes bodies
    # whose implementation_type is CODE — others stub out and raise so the
    # gap is visible (instead of silently no-oping). Sorted by name for a
    # deterministic generated output.
    #
    # Method.code can carry two shapes depending on the authoring tool:
    #   (a) just the body, e.g. ``self.x = self.x + 1``
    #   (b) the full ``def`` block, e.g. ``def step(self, dt): ...``
    # The web modeling editor saves shape (b). We detect it at generation
    # time and emit at class scope; otherwise we wrap with a generated
    # def header so a bare body still becomes a callable method.


class Stream:
    """
    Stream class from H2_Plant_Metamodel domain model.
    
    Attributes:
        tag (str): str attribute        name (str): str attribute    """
    
    def __init__(self, tag: Optional[str] = None, name: Optional[str] = None):
        """Initialize Stream instance."""
        self.tag = tag
        self.name = name
        
        # Association references
        self.sourcePort: Optional['Port'] = None
        self.targetPort: Optional['Port'] = None
    
    def to_dict(self) -> dict:
        """Convert instance to dictionary."""
        return {
            "class_name": "Stream",
            "tag": self.tag,
            "name": self.name,
            "sourcePort": [obj.to_dict() if hasattr(obj, 'to_dict') else str(obj) for obj in (self.sourcePort if isinstance(self.sourcePort, list) else [self.sourcePort] if self.sourcePort else [])],
            "targetPort": [obj.to_dict() if hasattr(obj, 'to_dict') else str(obj) for obj in (self.targetPort if isinstance(self.targetPort, list) else [self.targetPort] if self.targetPort else [])],
        }

    def __repr__(self) -> str:
        return f"Stream(tag={self.tag!r}, name={self.name!r})"

    # ------------------------------------------------------------------
    # User-authored behaviour
    # ------------------------------------------------------------------
    # Methods are emitted from cls.methods. Phase 1.0 only executes bodies
    # whose implementation_type is CODE — others stub out and raise so the
    # gap is visible (instead of silently no-oping). Sorted by name for a
    # deterministic generated output.
    #
    # Method.code can carry two shapes depending on the authoring tool:
    #   (a) just the body, e.g. ``self.x = self.x + 1``
    #   (b) the full ``def`` block, e.g. ``def step(self, dt): ...``
    # The web modeling editor saves shape (b). We detect it at generation
    # time and emit at class scope; otherwise we wrap with a generated
    # def header so a bare body still becomes a callable method.


class EnergyStream:
    """
    EnergyStream class from H2_Plant_Metamodel domain model.
    
    Attributes:
        energyType (str): str attribute        frequency (float): float attribute        name (str): str attribute        voltage (float): float attribute        power (float): float attribute        tag (str): str attribute    """
    
    def __init__(self, energyType: Optional[str] = None, frequency: Optional[float] = None, name: Optional[str] = None, voltage: Optional[float] = None, power: Optional[float] = None, tag: Optional[str] = None):
        """Initialize EnergyStream instance."""
        self.energyType = energyType
        self.frequency = frequency
        self.name = name
        self.voltage = voltage
        self.power = power
        self.tag = tag
        
        # Association references
        self.sourcePort: Optional['Port'] = None
        self.targetPort: Optional['Port'] = None
    
    def to_dict(self) -> dict:
        """Convert instance to dictionary."""
        return {
            "class_name": "EnergyStream",
            "energyType": self.energyType,
            "frequency": self.frequency,
            "name": self.name,
            "voltage": self.voltage,
            "power": self.power,
            "tag": self.tag,
            "sourcePort": [obj.to_dict() if hasattr(obj, 'to_dict') else str(obj) for obj in (self.sourcePort if isinstance(self.sourcePort, list) else [self.sourcePort] if self.sourcePort else [])],
            "targetPort": [obj.to_dict() if hasattr(obj, 'to_dict') else str(obj) for obj in (self.targetPort if isinstance(self.targetPort, list) else [self.targetPort] if self.targetPort else [])],
        }

    def __repr__(self) -> str:
        return f"EnergyStream(energyType={self.energyType!r}, frequency={self.frequency!r}, name={self.name!r}, voltage={self.voltage!r}, power={self.power!r}, tag={self.tag!r})"

    # ------------------------------------------------------------------
    # User-authored behaviour
    # ------------------------------------------------------------------
    # Methods are emitted from cls.methods. Phase 1.0 only executes bodies
    # whose implementation_type is CODE — others stub out and raise so the
    # gap is visible (instead of silently no-oping). Sorted by name for a
    # deterministic generated output.
    #
    # Method.code can carry two shapes depending on the authoring tool:
    #   (a) just the body, e.g. ``self.x = self.x + 1``
    #   (b) the full ``def`` block, e.g. ``def step(self, dt): ...``
    # The web modeling editor saves shape (b). We detect it at generation
    # time and emit at class scope; otherwise we wrap with a generated
    # def header so a bare body still becomes a callable method.


class MaterialStream:
    """
    MaterialStream class from H2_Plant_Metamodel domain model.
    
    Attributes:
        temperature (float): float attribute        enthalpy (float): float attribute        name (str): str attribute        phase (StreamPhase): StreamPhase attribute        massFlow (float): float attribute        density (float): float attribute        tag (str): str attribute        pressure (float): float attribute        vaporFraction (float): float attribute        molarFlow (float): float attribute    """
    
    def __init__(self, temperature: Optional[float] = None, enthalpy: Optional[float] = None, name: Optional[str] = None, phase: Optional[Any] = None, massFlow: Optional[float] = None, density: Optional[float] = None, tag: Optional[str] = None, pressure: Optional[float] = None, vaporFraction: Optional[float] = None, molarFlow: Optional[float] = None):
        """Initialize MaterialStream instance."""
        self.temperature = temperature
        self.enthalpy = enthalpy
        self.name = name
        self.phase = phase
        self.massFlow = massFlow
        self.density = density
        self.tag = tag
        self.pressure = pressure
        self.vaporFraction = vaporFraction
        self.molarFlow = molarFlow
        
        # Association references
        self.sourcePort: Optional['Port'] = None
        self.targetPort: Optional['Port'] = None
    
    def to_dict(self) -> dict:
        """Convert instance to dictionary."""
        return {
            "class_name": "MaterialStream",
            "temperature": self.temperature,
            "enthalpy": self.enthalpy,
            "name": self.name,
            "phase": self.phase,
            "massFlow": self.massFlow,
            "density": self.density,
            "tag": self.tag,
            "pressure": self.pressure,
            "vaporFraction": self.vaporFraction,
            "molarFlow": self.molarFlow,
            "sourcePort": [obj.to_dict() if hasattr(obj, 'to_dict') else str(obj) for obj in (self.sourcePort if isinstance(self.sourcePort, list) else [self.sourcePort] if self.sourcePort else [])],
            "targetPort": [obj.to_dict() if hasattr(obj, 'to_dict') else str(obj) for obj in (self.targetPort if isinstance(self.targetPort, list) else [self.targetPort] if self.targetPort else [])],
        }

    def __repr__(self) -> str:
        return f"MaterialStream(temperature={self.temperature!r}, enthalpy={self.enthalpy!r}, name={self.name!r}, phase={self.phase!r}, massFlow={self.massFlow!r}, density={self.density!r}, tag={self.tag!r}, pressure={self.pressure!r}, vaporFraction={self.vaporFraction!r}, molarFlow={self.molarFlow!r})"

    # ------------------------------------------------------------------
    # User-authored behaviour
    # ------------------------------------------------------------------
    # Methods are emitted from cls.methods. Phase 1.0 only executes bodies
    # whose implementation_type is CODE — others stub out and raise so the
    # gap is visible (instead of silently no-oping). Sorted by name for a
    # deterministic generated output.
    #
    # Method.code can carry two shapes depending on the authoring tool:
    #   (a) just the body, e.g. ``self.x = self.x + 1``
    #   (b) the full ``def`` block, e.g. ``def step(self, dt): ...``
    # The web modeling editor saves shape (b). We detect it at generation
    # time and emit at class scope; otherwise we wrap with a generated
    # def header so a bare body still becomes a callable method.


class Equipment:
    """
    Equipment class from H2_Plant_Metamodel domain model.
    
    Attributes:
        name (str): str attribute        status (EquipmentStatus): EquipmentStatus attribute        manufacturer (str): str attribute        tag (str): str attribute        modelNumber (str): str attribute        installationDate (date): date attribute    """
    
    def __init__(self, name: Optional[str] = None, status: Optional[Any] = None, manufacturer: Optional[str] = None, tag: Optional[str] = None, modelNumber: Optional[str] = None, installationDate: Optional[date] = None):
        """Initialize Equipment instance."""
        self.name = name
        self.status = status
        self.manufacturer = manufacturer
        self.tag = tag
        self.modelNumber = modelNumber
        self.installationDate = installationDate
        
        # Association references
        self.ports: List['Port'] = []
    
    def to_dict(self) -> dict:
        """Convert instance to dictionary."""
        return {
            "class_name": "Equipment",
            "name": self.name,
            "status": self.status,
            "manufacturer": self.manufacturer,
            "tag": self.tag,
            "modelNumber": self.modelNumber,
            "installationDate": self.installationDate,
            "ports": [obj.to_dict() if hasattr(obj, 'to_dict') else str(obj) for obj in (self.ports if isinstance(self.ports, list) else [self.ports] if self.ports else [])],
        }

    def __repr__(self) -> str:
        return f"Equipment(name={self.name!r}, status={self.status!r}, manufacturer={self.manufacturer!r}, tag={self.tag!r}, modelNumber={self.modelNumber!r}, installationDate={self.installationDate!r})"

    # ------------------------------------------------------------------
    # User-authored behaviour
    # ------------------------------------------------------------------
    # Methods are emitted from cls.methods. Phase 1.0 only executes bodies
    # whose implementation_type is CODE — others stub out and raise so the
    # gap is visible (instead of silently no-oping). Sorted by name for a
    # deterministic generated output.
    #
    # Method.code can carry two shapes depending on the authoring tool:
    #   (a) just the body, e.g. ``self.x = self.x + 1``
    #   (b) the full ``def`` block, e.g. ``def step(self, dt): ...``
    # The web modeling editor saves shape (b). We detect it at generation
    # time and emit at class scope; otherwise we wrap with a generated
    # def header so a bare body still becomes a callable method.


class TransportUnit:
    """
    TransportUnit class from H2_Plant_Metamodel domain model.
    
    Attributes:
        attribute (str): str attribute        name (str): str attribute        status (EquipmentStatus): EquipmentStatus attribute        manufacturer (str): str attribute        tag (str): str attribute        modelNumber (str): str attribute        installationDate (date): date attribute    """
    
    def __init__(self, attribute: Optional[str] = None, name: Optional[str] = None, status: Optional[Any] = None, manufacturer: Optional[str] = None, tag: Optional[str] = None, modelNumber: Optional[str] = None, installationDate: Optional[date] = None):
        """Initialize TransportUnit instance."""
        self.attribute = attribute
        self.name = name
        self.status = status
        self.manufacturer = manufacturer
        self.tag = tag
        self.modelNumber = modelNumber
        self.installationDate = installationDate
        
        # Association references
        self.ports: List['Port'] = []
    
    def to_dict(self) -> dict:
        """Convert instance to dictionary."""
        return {
            "class_name": "TransportUnit",
            "attribute": self.attribute,
            "name": self.name,
            "status": self.status,
            "manufacturer": self.manufacturer,
            "tag": self.tag,
            "modelNumber": self.modelNumber,
            "installationDate": self.installationDate,
            "ports": [obj.to_dict() if hasattr(obj, 'to_dict') else str(obj) for obj in (self.ports if isinstance(self.ports, list) else [self.ports] if self.ports else [])],
        }

    def __repr__(self) -> str:
        return f"TransportUnit(attribute={self.attribute!r}, name={self.name!r}, status={self.status!r}, manufacturer={self.manufacturer!r}, tag={self.tag!r}, modelNumber={self.modelNumber!r}, installationDate={self.installationDate!r})"

    # ------------------------------------------------------------------
    # User-authored behaviour
    # ------------------------------------------------------------------
    # Methods are emitted from cls.methods. Phase 1.0 only executes bodies
    # whose implementation_type is CODE — others stub out and raise so the
    # gap is visible (instead of silently no-oping). Sorted by name for a
    # deterministic generated output.
    #
    # Method.code can carry two shapes depending on the authoring tool:
    #   (a) just the body, e.g. ``self.x = self.x + 1``
    #   (b) the full ``def`` block, e.g. ``def step(self, dt): ...``
    # The web modeling editor saves shape (b). We detect it at generation
    # time and emit at class scope; otherwise we wrap with a generated
    # def header so a bare body still becomes a callable method.


class Truck:
    """
    Truck class from H2_Plant_Metamodel domain model.
    
    Attributes:
        attribute (str): str attribute        status (EquipmentStatus): EquipmentStatus attribute        manufacturer (str): str attribute        name (str): str attribute        tag (str): str attribute        currentLoad (float): float attribute        modelNumber (str): str attribute        capacity (float): float attribute        installationDate (date): date attribute    """
    
    def __init__(self, attribute: Optional[str] = None, status: Optional[Any] = None, manufacturer: Optional[str] = None, name: Optional[str] = None, tag: Optional[str] = None, currentLoad: Optional[float] = None, modelNumber: Optional[str] = None, capacity: Optional[float] = None, installationDate: Optional[date] = None):
        """Initialize Truck instance."""
        self.attribute = attribute
        self.status = status
        self.manufacturer = manufacturer
        self.name = name
        self.tag = tag
        self.currentLoad = currentLoad
        self.modelNumber = modelNumber
        self.capacity = capacity
        self.installationDate = installationDate
        
        # Association references
        self.ports: List['Port'] = []
    
    def to_dict(self) -> dict:
        """Convert instance to dictionary."""
        return {
            "class_name": "Truck",
            "attribute": self.attribute,
            "status": self.status,
            "manufacturer": self.manufacturer,
            "name": self.name,
            "tag": self.tag,
            "currentLoad": self.currentLoad,
            "modelNumber": self.modelNumber,
            "capacity": self.capacity,
            "installationDate": self.installationDate,
            "ports": [obj.to_dict() if hasattr(obj, 'to_dict') else str(obj) for obj in (self.ports if isinstance(self.ports, list) else [self.ports] if self.ports else [])],
        }

    def __repr__(self) -> str:
        return f"Truck(attribute={self.attribute!r}, status={self.status!r}, manufacturer={self.manufacturer!r}, name={self.name!r}, tag={self.tag!r}, currentLoad={self.currentLoad!r}, modelNumber={self.modelNumber!r}, capacity={self.capacity!r}, installationDate={self.installationDate!r})"

    # ------------------------------------------------------------------
    # User-authored behaviour
    # ------------------------------------------------------------------
    # Methods are emitted from cls.methods. Phase 1.0 only executes bodies
    # whose implementation_type is CODE — others stub out and raise so the
    # gap is visible (instead of silently no-oping). Sorted by name for a
    # deterministic generated output.
    #
    # Method.code can carry two shapes depending on the authoring tool:
    #   (a) just the body, e.g. ``self.x = self.x + 1``
    #   (b) the full ``def`` block, e.g. ``def step(self, dt): ...``
    # The web modeling editor saves shape (b). We detect it at generation
    # time and emit at class scope; otherwise we wrap with a generated
    # def header so a bare body still becomes a callable method.

    def deliver(self):
        """Simple loading / delivery cycle visible in the property inspector.

        currentLoad rises by 10 % of capacity per tick while loading.
        Once full (>= 95 %) the truck departs: currentLoad drops by 25 % per tick
        until empty, then the loading cycle restarts.
        """
        cap  = float(self.capacity or 500.0)
        load = float(self.currentLoad or 0.0)
        if load < cap * 0.95:
            self.currentLoad = round(min(cap, load + cap * 0.10), 2)
        else:
            self.currentLoad = round(max(0.0, load - cap * 0.25), 2)



class H2DeliveryPoint:
    """
    H2DeliveryPoint class from H2_Plant_Metamodel domain model.
    
    Attributes:
        attribute (str): str attribute        dispensingRate (float): float attribute        status (EquipmentStatus): EquipmentStatus attribute        manufacturer (str): str attribute        dispensingPressure (float): float attribute        name (str): str attribute        tag (str): str attribute        modelNumber (str): str attribute        tankCapacity (float): float attribute        currentLevel (float): float attribute        installationDate (date): date attribute    """
    
    def __init__(self, attribute: Optional[str] = None, dispensingRate: Optional[float] = None, status: Optional[Any] = None, manufacturer: Optional[str] = None, dispensingPressure: Optional[float] = None, name: Optional[str] = None, tag: Optional[str] = None, modelNumber: Optional[str] = None, tankCapacity: Optional[float] = None, currentLevel: Optional[float] = None, installationDate: Optional[date] = None):
        """Initialize H2DeliveryPoint instance."""
        self.attribute = attribute
        self.dispensingRate = dispensingRate
        self.status = status
        self.manufacturer = manufacturer
        self.dispensingPressure = dispensingPressure
        self.name = name
        self.tag = tag
        self.modelNumber = modelNumber
        self.tankCapacity = tankCapacity
        self.currentLevel = currentLevel
        self.installationDate = installationDate
        
        # Association references
        self.ports: List['Port'] = []
    
    def to_dict(self) -> dict:
        """Convert instance to dictionary."""
        return {
            "class_name": "H2DeliveryPoint",
            "attribute": self.attribute,
            "dispensingRate": self.dispensingRate,
            "status": self.status,
            "manufacturer": self.manufacturer,
            "dispensingPressure": self.dispensingPressure,
            "name": self.name,
            "tag": self.tag,
            "modelNumber": self.modelNumber,
            "tankCapacity": self.tankCapacity,
            "currentLevel": self.currentLevel,
            "installationDate": self.installationDate,
            "ports": [obj.to_dict() if hasattr(obj, 'to_dict') else str(obj) for obj in (self.ports if isinstance(self.ports, list) else [self.ports] if self.ports else [])],
        }

    def __repr__(self) -> str:
        return f"H2DeliveryPoint(attribute={self.attribute!r}, dispensingRate={self.dispensingRate!r}, status={self.status!r}, manufacturer={self.manufacturer!r}, dispensingPressure={self.dispensingPressure!r}, name={self.name!r}, tag={self.tag!r}, modelNumber={self.modelNumber!r}, tankCapacity={self.tankCapacity!r}, currentLevel={self.currentLevel!r}, installationDate={self.installationDate!r})"

    # ------------------------------------------------------------------
    # User-authored behaviour
    # ------------------------------------------------------------------
    # Methods are emitted from cls.methods. Phase 1.0 only executes bodies
    # whose implementation_type is CODE — others stub out and raise so the
    # gap is visible (instead of silently no-oping). Sorted by name for a
    # deterministic generated output.
    #
    # Method.code can carry two shapes depending on the authoring tool:
    #   (a) just the body, e.g. ``self.x = self.x + 1``
    #   (b) the full ``def`` block, e.g. ``def step(self, dt): ...``
    # The web modeling editor saves shape (b). We detect it at generation
    # time and emit at class scope; otherwise we wrap with a generated
    # def header so a bare body still becomes a callable method.

    def dispense_h2(self):
        """Dispense H2 to refuelling buses at dispensingRate [kg/tick].
        When the tank runs dry it auto-refills to 80 % capacity, simulating
        a delivery from the storage tank.
        """
        rate    = float(self.dispensingRate or 5.0)
        current = float(self.currentLevel or 0.0)
        cap     = float(self.tankCapacity or 200.0)
        if current > 0:
            self.currentLevel = round(max(0.0, current - rate), 2)
        else:
            self.currentLevel = round(cap * 0.8, 2)   # refill from storage



class PowerSource:
    """
    PowerSource class from H2_Plant_Metamodel domain model.
    
    Attributes:
        status (EquipmentStatus): EquipmentStatus attribute        manufacturer (str): str attribute        ratedPower (float): float attribute        name (str): str attribute        tag (str): str attribute        modelNumber (str): str attribute        availability (float): float attribute        installationDate (date): date attribute    """
    
    def __init__(self, status: Optional[Any] = None, manufacturer: Optional[str] = None, ratedPower: Optional[float] = None, name: Optional[str] = None, tag: Optional[str] = None, modelNumber: Optional[str] = None, availability: Optional[float] = None, installationDate: Optional[date] = None):
        """Initialize PowerSource instance."""
        self.status = status
        self.manufacturer = manufacturer
        self.ratedPower = ratedPower
        self.name = name
        self.tag = tag
        self.modelNumber = modelNumber
        self.availability = availability
        self.installationDate = installationDate
        
        # Association references
        self.ports: List['Port'] = []
    
    def to_dict(self) -> dict:
        """Convert instance to dictionary."""
        return {
            "class_name": "PowerSource",
            "status": self.status,
            "manufacturer": self.manufacturer,
            "ratedPower": self.ratedPower,
            "name": self.name,
            "tag": self.tag,
            "modelNumber": self.modelNumber,
            "availability": self.availability,
            "installationDate": self.installationDate,
            "ports": [obj.to_dict() if hasattr(obj, 'to_dict') else str(obj) for obj in (self.ports if isinstance(self.ports, list) else [self.ports] if self.ports else [])],
        }

    def __repr__(self) -> str:
        return f"PowerSource(status={self.status!r}, manufacturer={self.manufacturer!r}, ratedPower={self.ratedPower!r}, name={self.name!r}, tag={self.tag!r}, modelNumber={self.modelNumber!r}, availability={self.availability!r}, installationDate={self.installationDate!r})"

    # ------------------------------------------------------------------
    # User-authored behaviour
    # ------------------------------------------------------------------
    # Methods are emitted from cls.methods. Phase 1.0 only executes bodies
    # whose implementation_type is CODE — others stub out and raise so the
    # gap is visible (instead of silently no-oping). Sorted by name for a
    # deterministic generated output.
    #
    # Method.code can carry two shapes depending on the authoring tool:
    #   (a) just the body, e.g. ``self.x = self.x + 1``
    #   (b) the full ``def`` block, e.g. ``def step(self, dt): ...``
    # The web modeling editor saves shape (b). We detect it at generation
    # time and emit at class scope; otherwise we wrap with a generated
    # def header so a bare body still becomes a callable method.


class UnitOperation:
    """
    UnitOperation class from H2_Plant_Metamodel domain model.
    
    Attributes:
        name (str): str attribute        status (EquipmentStatus): EquipmentStatus attribute        manufacturer (str): str attribute        tag (str): str attribute        modelNumber (str): str attribute        installationDate (date): date attribute    """
    
    def __init__(self, name: Optional[str] = None, status: Optional[Any] = None, manufacturer: Optional[str] = None, tag: Optional[str] = None, modelNumber: Optional[str] = None, installationDate: Optional[date] = None):
        """Initialize UnitOperation instance."""
        self.name = name
        self.status = status
        self.manufacturer = manufacturer
        self.tag = tag
        self.modelNumber = modelNumber
        self.installationDate = installationDate
        
        # Association references
        self.ports: List['Port'] = []
    
    def to_dict(self) -> dict:
        """Convert instance to dictionary."""
        return {
            "class_name": "UnitOperation",
            "name": self.name,
            "status": self.status,
            "manufacturer": self.manufacturer,
            "tag": self.tag,
            "modelNumber": self.modelNumber,
            "installationDate": self.installationDate,
            "ports": [obj.to_dict() if hasattr(obj, 'to_dict') else str(obj) for obj in (self.ports if isinstance(self.ports, list) else [self.ports] if self.ports else [])],
        }

    def __repr__(self) -> str:
        return f"UnitOperation(name={self.name!r}, status={self.status!r}, manufacturer={self.manufacturer!r}, tag={self.tag!r}, modelNumber={self.modelNumber!r}, installationDate={self.installationDate!r})"

    # ------------------------------------------------------------------
    # User-authored behaviour
    # ------------------------------------------------------------------
    # Methods are emitted from cls.methods. Phase 1.0 only executes bodies
    # whose implementation_type is CODE — others stub out and raise so the
    # gap is visible (instead of silently no-oping). Sorted by name for a
    # deterministic generated output.
    #
    # Method.code can carry two shapes depending on the authoring tool:
    #   (a) just the body, e.g. ``self.x = self.x + 1``
    #   (b) the full ``def`` block, e.g. ``def step(self, dt): ...``
    # The web modeling editor saves shape (b). We detect it at generation
    # time and emit at class scope; otherwise we wrap with a generated
    # def header so a bare body still becomes a callable method.


class Electrolyzer:
    """
    Electrolyzer class from H2_Plant_Metamodel domain model.
    
    Attributes:
        installationDate (date): date attribute        operatingTemperature (float): float attribute        status (EquipmentStatus): EquipmentStatus attribute        manufacturer (str): str attribute        nominalPower (float): float attribute        maxLoad (float): float attribute        stackVoltage (float): float attribute        operatingPressure (float): float attribute        name (str): str attribute        tag (str): str attribute        nominalH2Production (float): float attribute        modelNumber (str): str attribute        stackCurrent (float): float attribute        minLoad (float): float attribute        specificEnergyConsumption (float): float attribute    """
    
    def __init__(self, installationDate: Optional[date] = None, operatingTemperature: Optional[float] = None, status: Optional[Any] = None, manufacturer: Optional[str] = None, nominalPower: Optional[float] = None, maxLoad: Optional[float] = None, stackVoltage: Optional[float] = None, operatingPressure: Optional[float] = None, name: Optional[str] = None, tag: Optional[str] = None, nominalH2Production: Optional[float] = None, modelNumber: Optional[str] = None, stackCurrent: Optional[float] = None, minLoad: Optional[float] = None, specificEnergyConsumption: Optional[float] = None):
        """Initialize Electrolyzer instance."""
        self.installationDate = installationDate
        self.operatingTemperature = operatingTemperature
        self.status = status
        self.manufacturer = manufacturer
        self.nominalPower = nominalPower
        self.maxLoad = maxLoad
        self.stackVoltage = stackVoltage
        self.operatingPressure = operatingPressure
        self.name = name
        self.tag = tag
        self.nominalH2Production = nominalH2Production
        self.modelNumber = modelNumber
        self.stackCurrent = stackCurrent
        self.minLoad = minLoad
        self.specificEnergyConsumption = specificEnergyConsumption
        
        # Association references
        self.ports: List['Port'] = []
    
    def to_dict(self) -> dict:
        """Convert instance to dictionary."""
        return {
            "class_name": "Electrolyzer",
            "installationDate": self.installationDate,
            "operatingTemperature": self.operatingTemperature,
            "status": self.status,
            "manufacturer": self.manufacturer,
            "nominalPower": self.nominalPower,
            "maxLoad": self.maxLoad,
            "stackVoltage": self.stackVoltage,
            "operatingPressure": self.operatingPressure,
            "name": self.name,
            "tag": self.tag,
            "nominalH2Production": self.nominalH2Production,
            "modelNumber": self.modelNumber,
            "stackCurrent": self.stackCurrent,
            "minLoad": self.minLoad,
            "specificEnergyConsumption": self.specificEnergyConsumption,
            "ports": [obj.to_dict() if hasattr(obj, 'to_dict') else str(obj) for obj in (self.ports if isinstance(self.ports, list) else [self.ports] if self.ports else [])],
        }

    def __repr__(self) -> str:
        return f"Electrolyzer(installationDate={self.installationDate!r}, operatingTemperature={self.operatingTemperature!r}, status={self.status!r}, manufacturer={self.manufacturer!r}, nominalPower={self.nominalPower!r}, maxLoad={self.maxLoad!r}, stackVoltage={self.stackVoltage!r}, operatingPressure={self.operatingPressure!r}, name={self.name!r}, tag={self.tag!r}, nominalH2Production={self.nominalH2Production!r}, modelNumber={self.modelNumber!r}, stackCurrent={self.stackCurrent!r}, minLoad={self.minLoad!r}, specificEnergyConsumption={self.specificEnergyConsumption!r})"

    # ------------------------------------------------------------------
    # User-authored behaviour
    # ------------------------------------------------------------------
    # Methods are emitted from cls.methods. Phase 1.0 only executes bodies
    # whose implementation_type is CODE — others stub out and raise so the
    # gap is visible (instead of silently no-oping). Sorted by name for a
    # deterministic generated output.
    #
    # Method.code can carry two shapes depending on the authoring tool:
    #   (a) just the body, e.g. ``self.x = self.x + 1``
    #   (b) the full ``def`` block, e.g. ``def step(self, dt): ...``
    # The web modeling editor saves shape (b). We detect it at generation
    # time and emit at class scope; otherwise we wrap with a generated
    # def header so a bare body still becomes a callable method.

    def produce_h2(self):
        """Simulate H2 production based on available electrical power.

        stackCurrent [A]  tracks the electrical load each tick.
        nominalH2Production [kg/h] shows the instantaneous production rate.
        operatingPressure [bar] climbs to 30 bar as the system pressurises.
        """
        import random
        nom_pwr = float(self.nominalPower or 100.0)      # kW rated
        min_ld  = float(self.minLoad or 0.2)
        max_ld  = float(self.maxLoad or 1.0)
        spec_e  = float(self.specificEnergyConsumption or 50.0)  # kWh/kg

        # Load drifts +/-5 % per tick, simulating renewable power fluctuation
        stack_v = 180.0                                   # 100-cell PEM at 1.8 V/cell
        prev_i  = float(self.stackCurrent or 0.0)
        prev_ld = prev_i / max(1.0, nom_pwr * 1000.0 / stack_v)
        new_ld  = max(min_ld, min(max_ld, prev_ld + (random.random() - 0.5) * 0.1))

        self.stackVoltage        = round(stack_v, 1)
        self.stackCurrent        = round(new_ld * nom_pwr * 1000.0 / stack_v, 1)
        self.nominalH2Production = round((new_ld * nom_pwr) / spec_e, 3)  # live rate
        op_p = float(self.operatingPressure or 1.0)
        self.operatingPressure   = round(min(30.0, op_p + 0.5), 1)



class SOECElectrolyzer:
    """
    SOECElectrolyzer class from H2_Plant_Metamodel domain model.
    
    Attributes:
        status (EquipmentStatus): EquipmentStatus attribute        operatingTemperature (float): float attribute        nominalPower (float): float attribute        stackVoltage (float): float attribute        operatingPressure (float): float attribute        modelNumber (str): str attribute        installationDate (date): date attribute        manufacturer (str): str attribute        maxLoad (float): float attribute        ceramicMaterial (str): str attribute        operatingTempSOEC (float): float attribute        name (str): str attribute        tag (str): str attribute        nominalH2Production (float): float attribute        stackCurrent (float): float attribute        minLoad (float): float attribute        specificEnergyConsumption (float): float attribute    """
    
    def __init__(self, status: Optional[Any] = None, operatingTemperature: Optional[float] = None, nominalPower: Optional[float] = None, stackVoltage: Optional[float] = None, operatingPressure: Optional[float] = None, modelNumber: Optional[str] = None, installationDate: Optional[date] = None, manufacturer: Optional[str] = None, maxLoad: Optional[float] = None, ceramicMaterial: Optional[str] = None, operatingTempSOEC: Optional[float] = None, name: Optional[str] = None, tag: Optional[str] = None, nominalH2Production: Optional[float] = None, stackCurrent: Optional[float] = None, minLoad: Optional[float] = None, specificEnergyConsumption: Optional[float] = None):
        """Initialize SOECElectrolyzer instance."""
        self.status = status
        self.operatingTemperature = operatingTemperature
        self.nominalPower = nominalPower
        self.stackVoltage = stackVoltage
        self.operatingPressure = operatingPressure
        self.modelNumber = modelNumber
        self.installationDate = installationDate
        self.manufacturer = manufacturer
        self.maxLoad = maxLoad
        self.ceramicMaterial = ceramicMaterial
        self.operatingTempSOEC = operatingTempSOEC
        self.name = name
        self.tag = tag
        self.nominalH2Production = nominalH2Production
        self.stackCurrent = stackCurrent
        self.minLoad = minLoad
        self.specificEnergyConsumption = specificEnergyConsumption
        
        # Association references
        self.ports: List['Port'] = []
    
    def to_dict(self) -> dict:
        """Convert instance to dictionary."""
        return {
            "class_name": "SOECElectrolyzer",
            "status": self.status,
            "operatingTemperature": self.operatingTemperature,
            "nominalPower": self.nominalPower,
            "stackVoltage": self.stackVoltage,
            "operatingPressure": self.operatingPressure,
            "modelNumber": self.modelNumber,
            "installationDate": self.installationDate,
            "manufacturer": self.manufacturer,
            "maxLoad": self.maxLoad,
            "ceramicMaterial": self.ceramicMaterial,
            "operatingTempSOEC": self.operatingTempSOEC,
            "name": self.name,
            "tag": self.tag,
            "nominalH2Production": self.nominalH2Production,
            "stackCurrent": self.stackCurrent,
            "minLoad": self.minLoad,
            "specificEnergyConsumption": self.specificEnergyConsumption,
            "ports": [obj.to_dict() if hasattr(obj, 'to_dict') else str(obj) for obj in (self.ports if isinstance(self.ports, list) else [self.ports] if self.ports else [])],
        }

    def __repr__(self) -> str:
        return f"SOECElectrolyzer(status={self.status!r}, operatingTemperature={self.operatingTemperature!r}, nominalPower={self.nominalPower!r}, stackVoltage={self.stackVoltage!r}, operatingPressure={self.operatingPressure!r}, modelNumber={self.modelNumber!r}, installationDate={self.installationDate!r}, manufacturer={self.manufacturer!r}, maxLoad={self.maxLoad!r}, ceramicMaterial={self.ceramicMaterial!r}, operatingTempSOEC={self.operatingTempSOEC!r}, name={self.name!r}, tag={self.tag!r}, nominalH2Production={self.nominalH2Production!r}, stackCurrent={self.stackCurrent!r}, minLoad={self.minLoad!r}, specificEnergyConsumption={self.specificEnergyConsumption!r})"

    # ------------------------------------------------------------------
    # User-authored behaviour
    # ------------------------------------------------------------------
    # Methods are emitted from cls.methods. Phase 1.0 only executes bodies
    # whose implementation_type is CODE — others stub out and raise so the
    # gap is visible (instead of silently no-oping). Sorted by name for a
    # deterministic generated output.
    #
    # Method.code can carry two shapes depending on the authoring tool:
    #   (a) just the body, e.g. ``self.x = self.x + 1``
    #   (b) the full ``def`` block, e.g. ``def step(self, dt): ...``
    # The web modeling editor saves shape (b). We detect it at generation
    # time and emit at class scope; otherwise we wrap with a generated
    # def header so a bare body still becomes a callable method.


class AlkalineElectrolyzer:
    """
    AlkalineElectrolyzer class from H2_Plant_Metamodel domain model.
    
    Attributes:
        status (EquipmentStatus): EquipmentStatus attribute        operatingTemperature (float): float attribute        nominalPower (float): float attribute        stackVoltage (float): float attribute        operatingPressure (float): float attribute        bubblePoint (float): float attribute        modelNumber (str): str attribute        electrolyteConcentration (float): float attribute        installationDate (date): date attribute        manufacturer (str): str attribute        maxLoad (float): float attribute        name (str): str attribute        tag (str): str attribute        nominalH2Production (float): float attribute        stackCurrent (float): float attribute        minLoad (float): float attribute        specificEnergyConsumption (float): float attribute    """
    
    def __init__(self, status: Optional[Any] = None, operatingTemperature: Optional[float] = None, nominalPower: Optional[float] = None, stackVoltage: Optional[float] = None, operatingPressure: Optional[float] = None, bubblePoint: Optional[float] = None, modelNumber: Optional[str] = None, electrolyteConcentration: Optional[float] = None, installationDate: Optional[date] = None, manufacturer: Optional[str] = None, maxLoad: Optional[float] = None, name: Optional[str] = None, tag: Optional[str] = None, nominalH2Production: Optional[float] = None, stackCurrent: Optional[float] = None, minLoad: Optional[float] = None, specificEnergyConsumption: Optional[float] = None):
        """Initialize AlkalineElectrolyzer instance."""
        self.status = status
        self.operatingTemperature = operatingTemperature
        self.nominalPower = nominalPower
        self.stackVoltage = stackVoltage
        self.operatingPressure = operatingPressure
        self.bubblePoint = bubblePoint
        self.modelNumber = modelNumber
        self.electrolyteConcentration = electrolyteConcentration
        self.installationDate = installationDate
        self.manufacturer = manufacturer
        self.maxLoad = maxLoad
        self.name = name
        self.tag = tag
        self.nominalH2Production = nominalH2Production
        self.stackCurrent = stackCurrent
        self.minLoad = minLoad
        self.specificEnergyConsumption = specificEnergyConsumption
        
        # Association references
        self.ports: List['Port'] = []
    
    def to_dict(self) -> dict:
        """Convert instance to dictionary."""
        return {
            "class_name": "AlkalineElectrolyzer",
            "status": self.status,
            "operatingTemperature": self.operatingTemperature,
            "nominalPower": self.nominalPower,
            "stackVoltage": self.stackVoltage,
            "operatingPressure": self.operatingPressure,
            "bubblePoint": self.bubblePoint,
            "modelNumber": self.modelNumber,
            "electrolyteConcentration": self.electrolyteConcentration,
            "installationDate": self.installationDate,
            "manufacturer": self.manufacturer,
            "maxLoad": self.maxLoad,
            "name": self.name,
            "tag": self.tag,
            "nominalH2Production": self.nominalH2Production,
            "stackCurrent": self.stackCurrent,
            "minLoad": self.minLoad,
            "specificEnergyConsumption": self.specificEnergyConsumption,
            "ports": [obj.to_dict() if hasattr(obj, 'to_dict') else str(obj) for obj in (self.ports if isinstance(self.ports, list) else [self.ports] if self.ports else [])],
        }

    def __repr__(self) -> str:
        return f"AlkalineElectrolyzer(status={self.status!r}, operatingTemperature={self.operatingTemperature!r}, nominalPower={self.nominalPower!r}, stackVoltage={self.stackVoltage!r}, operatingPressure={self.operatingPressure!r}, bubblePoint={self.bubblePoint!r}, modelNumber={self.modelNumber!r}, electrolyteConcentration={self.electrolyteConcentration!r}, installationDate={self.installationDate!r}, manufacturer={self.manufacturer!r}, maxLoad={self.maxLoad!r}, name={self.name!r}, tag={self.tag!r}, nominalH2Production={self.nominalH2Production!r}, stackCurrent={self.stackCurrent!r}, minLoad={self.minLoad!r}, specificEnergyConsumption={self.specificEnergyConsumption!r})"

    # ------------------------------------------------------------------
    # User-authored behaviour
    # ------------------------------------------------------------------
    # Methods are emitted from cls.methods. Phase 1.0 only executes bodies
    # whose implementation_type is CODE — others stub out and raise so the
    # gap is visible (instead of silently no-oping). Sorted by name for a
    # deterministic generated output.
    #
    # Method.code can carry two shapes depending on the authoring tool:
    #   (a) just the body, e.g. ``self.x = self.x + 1``
    #   (b) the full ``def`` block, e.g. ``def step(self, dt): ...``
    # The web modeling editor saves shape (b). We detect it at generation
    # time and emit at class scope; otherwise we wrap with a generated
    # def header so a bare body still becomes a callable method.


class PEMElectrolyzer:
    """
    PEMElectrolyzer class from H2_Plant_Metamodel domain model.
    
    Attributes:
        membraneArea (float): float attribute        status (EquipmentStatus): EquipmentStatus attribute        operatingTemperature (float): float attribute        nominalPower (float): float attribute        membraneThickness (float): float attribute        stackVoltage (float): float attribute        operatingPressure (float): float attribute        modelNumber (str): str attribute        installationDate (date): date attribute        manufacturer (str): str attribute        maxLoad (float): float attribute        name (str): str attribute        tag (str): str attribute        nominalH2Production (float): float attribute        stackCurrent (float): float attribute        minLoad (float): float attribute        specificEnergyConsumption (float): float attribute    """
    
    def __init__(self, membraneArea: Optional[float] = None, status: Optional[Any] = None, operatingTemperature: Optional[float] = None, nominalPower: Optional[float] = None, membraneThickness: Optional[float] = None, stackVoltage: Optional[float] = None, operatingPressure: Optional[float] = None, modelNumber: Optional[str] = None, installationDate: Optional[date] = None, manufacturer: Optional[str] = None, maxLoad: Optional[float] = None, name: Optional[str] = None, tag: Optional[str] = None, nominalH2Production: Optional[float] = None, stackCurrent: Optional[float] = None, minLoad: Optional[float] = None, specificEnergyConsumption: Optional[float] = None):
        """Initialize PEMElectrolyzer instance."""
        self.membraneArea = membraneArea
        self.status = status
        self.operatingTemperature = operatingTemperature
        self.nominalPower = nominalPower
        self.membraneThickness = membraneThickness
        self.stackVoltage = stackVoltage
        self.operatingPressure = operatingPressure
        self.modelNumber = modelNumber
        self.installationDate = installationDate
        self.manufacturer = manufacturer
        self.maxLoad = maxLoad
        self.name = name
        self.tag = tag
        self.nominalH2Production = nominalH2Production
        self.stackCurrent = stackCurrent
        self.minLoad = minLoad
        self.specificEnergyConsumption = specificEnergyConsumption
        
        # Association references
        self.ports: List['Port'] = []
    
    def to_dict(self) -> dict:
        """Convert instance to dictionary."""
        return {
            "class_name": "PEMElectrolyzer",
            "membraneArea": self.membraneArea,
            "status": self.status,
            "operatingTemperature": self.operatingTemperature,
            "nominalPower": self.nominalPower,
            "membraneThickness": self.membraneThickness,
            "stackVoltage": self.stackVoltage,
            "operatingPressure": self.operatingPressure,
            "modelNumber": self.modelNumber,
            "installationDate": self.installationDate,
            "manufacturer": self.manufacturer,
            "maxLoad": self.maxLoad,
            "name": self.name,
            "tag": self.tag,
            "nominalH2Production": self.nominalH2Production,
            "stackCurrent": self.stackCurrent,
            "minLoad": self.minLoad,
            "specificEnergyConsumption": self.specificEnergyConsumption,
            "ports": [obj.to_dict() if hasattr(obj, 'to_dict') else str(obj) for obj in (self.ports if isinstance(self.ports, list) else [self.ports] if self.ports else [])],
        }

    def __repr__(self) -> str:
        return f"PEMElectrolyzer(membraneArea={self.membraneArea!r}, status={self.status!r}, operatingTemperature={self.operatingTemperature!r}, nominalPower={self.nominalPower!r}, membraneThickness={self.membraneThickness!r}, stackVoltage={self.stackVoltage!r}, operatingPressure={self.operatingPressure!r}, modelNumber={self.modelNumber!r}, installationDate={self.installationDate!r}, manufacturer={self.manufacturer!r}, maxLoad={self.maxLoad!r}, name={self.name!r}, tag={self.tag!r}, nominalH2Production={self.nominalH2Production!r}, stackCurrent={self.stackCurrent!r}, minLoad={self.minLoad!r}, specificEnergyConsumption={self.specificEnergyConsumption!r})"

    # ------------------------------------------------------------------
    # User-authored behaviour
    # ------------------------------------------------------------------
    # Methods are emitted from cls.methods. Phase 1.0 only executes bodies
    # whose implementation_type is CODE — others stub out and raise so the
    # gap is visible (instead of silently no-oping). Sorted by name for a
    # deterministic generated output.
    #
    # Method.code can carry two shapes depending on the authoring tool:
    #   (a) just the body, e.g. ``self.x = self.x + 1``
    #   (b) the full ``def`` block, e.g. ``def step(self, dt): ...``
    # The web modeling editor saves shape (b). We detect it at generation
    # time and emit at class scope; otherwise we wrap with a generated
    # def header so a bare body still becomes a callable method.


class GridConnection:
    """
    GridConnection class from H2_Plant_Metamodel domain model.
    
    Attributes:
        frequency (float): float attribute        status (EquipmentStatus): EquipmentStatus attribute        manufacturer (str): str attribute        ratedPower (float): float attribute        voltage (float): float attribute        maxPower (float): float attribute        name (str): str attribute        tag (str): str attribute        modelNumber (str): str attribute        availability (float): float attribute        installationDate (date): date attribute    """
    
    def __init__(self, frequency: Optional[float] = None, status: Optional[Any] = None, manufacturer: Optional[str] = None, ratedPower: Optional[float] = None, voltage: Optional[float] = None, maxPower: Optional[float] = None, name: Optional[str] = None, tag: Optional[str] = None, modelNumber: Optional[str] = None, availability: Optional[float] = None, installationDate: Optional[date] = None):
        """Initialize GridConnection instance."""
        self.frequency = frequency
        self.status = status
        self.manufacturer = manufacturer
        self.ratedPower = ratedPower
        self.voltage = voltage
        self.maxPower = maxPower
        self.name = name
        self.tag = tag
        self.modelNumber = modelNumber
        self.availability = availability
        self.installationDate = installationDate
        
        # Association references
        self.ports: List['Port'] = []
    
    def to_dict(self) -> dict:
        """Convert instance to dictionary."""
        return {
            "class_name": "GridConnection",
            "frequency": self.frequency,
            "status": self.status,
            "manufacturer": self.manufacturer,
            "ratedPower": self.ratedPower,
            "voltage": self.voltage,
            "maxPower": self.maxPower,
            "name": self.name,
            "tag": self.tag,
            "modelNumber": self.modelNumber,
            "availability": self.availability,
            "installationDate": self.installationDate,
            "ports": [obj.to_dict() if hasattr(obj, 'to_dict') else str(obj) for obj in (self.ports if isinstance(self.ports, list) else [self.ports] if self.ports else [])],
        }

    def __repr__(self) -> str:
        return f"GridConnection(frequency={self.frequency!r}, status={self.status!r}, manufacturer={self.manufacturer!r}, ratedPower={self.ratedPower!r}, voltage={self.voltage!r}, maxPower={self.maxPower!r}, name={self.name!r}, tag={self.tag!r}, modelNumber={self.modelNumber!r}, availability={self.availability!r}, installationDate={self.installationDate!r})"

    # ------------------------------------------------------------------
    # User-authored behaviour
    # ------------------------------------------------------------------
    # Methods are emitted from cls.methods. Phase 1.0 only executes bodies
    # whose implementation_type is CODE — others stub out and raise so the
    # gap is visible (instead of silently no-oping). Sorted by name for a
    # deterministic generated output.
    #
    # Method.code can carry two shapes depending on the authoring tool:
    #   (a) just the body, e.g. ``self.x = self.x + 1``
    #   (b) the full ``def`` block, e.g. ``def step(self, dt): ...``
    # The web modeling editor saves shape (b). We detect it at generation
    # time and emit at class scope; otherwise we wrap with a generated
    # def header so a bare body still becomes a callable method.


class WindFarm:
    """
    WindFarm class from H2_Plant_Metamodel domain model.
    
    Attributes:
        ratedWindSpeed (float): float attribute        status (EquipmentStatus): EquipmentStatus attribute        manufacturer (str): str attribute        ratedPower (float): float attribute        currentPower (float): float attribute        turbineCount (int): int attribute        hubHeight (float): float attribute        name (str): str attribute        tag (str): str attribute        modelNumber (str): str attribute        availability (float): float attribute        installationDate (date): date attribute    """
    
    def __init__(self, ratedWindSpeed: Optional[float] = None, status: Optional[Any] = None, manufacturer: Optional[str] = None, ratedPower: Optional[float] = None, currentPower: Optional[float] = None, turbineCount: Optional[int] = None, hubHeight: Optional[float] = None, name: Optional[str] = None, tag: Optional[str] = None, modelNumber: Optional[str] = None, availability: Optional[float] = None, installationDate: Optional[date] = None):
        """Initialize WindFarm instance."""
        self.ratedWindSpeed = ratedWindSpeed
        self.status = status
        self.manufacturer = manufacturer
        self.ratedPower = ratedPower
        self.currentPower = currentPower
        self.turbineCount = turbineCount
        self.hubHeight = hubHeight
        self.name = name
        self.tag = tag
        self.modelNumber = modelNumber
        self.availability = availability
        self.installationDate = installationDate
        
        # Association references
        self.ports: List['Port'] = []
    
    def to_dict(self) -> dict:
        """Convert instance to dictionary."""
        return {
            "class_name": "WindFarm",
            "ratedWindSpeed": self.ratedWindSpeed,
            "status": self.status,
            "manufacturer": self.manufacturer,
            "ratedPower": self.ratedPower,
            "currentPower": self.currentPower,
            "turbineCount": self.turbineCount,
            "hubHeight": self.hubHeight,
            "name": self.name,
            "tag": self.tag,
            "modelNumber": self.modelNumber,
            "availability": self.availability,
            "installationDate": self.installationDate,
            "ports": [obj.to_dict() if hasattr(obj, 'to_dict') else str(obj) for obj in (self.ports if isinstance(self.ports, list) else [self.ports] if self.ports else [])],
        }

    def __repr__(self) -> str:
        return f"WindFarm(ratedWindSpeed={self.ratedWindSpeed!r}, status={self.status!r}, manufacturer={self.manufacturer!r}, ratedPower={self.ratedPower!r}, currentPower={self.currentPower!r}, turbineCount={self.turbineCount!r}, hubHeight={self.hubHeight!r}, name={self.name!r}, tag={self.tag!r}, modelNumber={self.modelNumber!r}, availability={self.availability!r}, installationDate={self.installationDate!r})"

    # ------------------------------------------------------------------
    # User-authored behaviour
    # ------------------------------------------------------------------
    # Methods are emitted from cls.methods. Phase 1.0 only executes bodies
    # whose implementation_type is CODE — others stub out and raise so the
    # gap is visible (instead of silently no-oping). Sorted by name for a
    # deterministic generated output.
    #
    # Method.code can carry two shapes depending on the authoring tool:
    #   (a) just the body, e.g. ``self.x = self.x + 1``
    #   (b) the full ``def`` block, e.g. ``def step(self, dt): ...``
    # The web modeling editor saves shape (b). We detect it at generation
    # time and emit at class scope; otherwise we wrap with a generated
    # def header so a bare body still becomes a callable method.

    def compute_output(self):
        """Stochastic wind power output (±20 % around rated capacity).
        Updates currentPower with instantaneous generation in kW.
        """
        import random
        turbines = int(self.turbineCount or 3)
        rated_speed = float(self.ratedWindSpeed or 12.0)
        # Simulate variable wind speed around rated speed
        wind_speed = rated_speed * (0.6 + random.random() * 0.8)
        rated_kw = turbines * 333.0  # ~1 MW total for 3 × 333 kW turbines
        if wind_speed < 3.0:
            self.currentPower = 0.0
        elif wind_speed >= rated_speed:
            self.currentPower = round(rated_kw, 2)
        else:
            factor = (wind_speed / rated_speed) ** 3
            self.currentPower = round(rated_kw * factor, 2)



class SolarFarm:
    """
    SolarFarm class from H2_Plant_Metamodel domain model.
    
    Attributes:
        installationDate (date): date attribute        status (EquipmentStatus): EquipmentStatus attribute        manufacturer (str): str attribute        ratedPower (float): float attribute        area (float): float attribute        name (str): str attribute        tag (str): str attribute        modelNumber (str): str attribute        availability (float): float attribute        panelCount (int): int attribute        peakPower (float): float attribute    """
    
    def __init__(self, installationDate: Optional[date] = None, status: Optional[Any] = None, manufacturer: Optional[str] = None, ratedPower: Optional[float] = None, area: Optional[float] = None, name: Optional[str] = None, tag: Optional[str] = None, modelNumber: Optional[str] = None, availability: Optional[float] = None, panelCount: Optional[int] = None, peakPower: Optional[float] = None):
        """Initialize SolarFarm instance."""
        self.installationDate = installationDate
        self.status = status
        self.manufacturer = manufacturer
        self.ratedPower = ratedPower
        self.area = area
        self.name = name
        self.tag = tag
        self.modelNumber = modelNumber
        self.availability = availability
        self.panelCount = panelCount
        self.peakPower = peakPower
        
        # Association references
        self.ports: List['Port'] = []
    
    def to_dict(self) -> dict:
        """Convert instance to dictionary."""
        return {
            "class_name": "SolarFarm",
            "installationDate": self.installationDate,
            "status": self.status,
            "manufacturer": self.manufacturer,
            "ratedPower": self.ratedPower,
            "area": self.area,
            "name": self.name,
            "tag": self.tag,
            "modelNumber": self.modelNumber,
            "availability": self.availability,
            "panelCount": self.panelCount,
            "peakPower": self.peakPower,
            "ports": [obj.to_dict() if hasattr(obj, 'to_dict') else str(obj) for obj in (self.ports if isinstance(self.ports, list) else [self.ports] if self.ports else [])],
        }

    def __repr__(self) -> str:
        return f"SolarFarm(installationDate={self.installationDate!r}, status={self.status!r}, manufacturer={self.manufacturer!r}, ratedPower={self.ratedPower!r}, area={self.area!r}, name={self.name!r}, tag={self.tag!r}, modelNumber={self.modelNumber!r}, availability={self.availability!r}, panelCount={self.panelCount!r}, peakPower={self.peakPower!r})"

    # ------------------------------------------------------------------
    # User-authored behaviour
    # ------------------------------------------------------------------
    # Methods are emitted from cls.methods. Phase 1.0 only executes bodies
    # whose implementation_type is CODE — others stub out and raise so the
    # gap is visible (instead of silently no-oping). Sorted by name for a
    # deterministic generated output.
    #
    # Method.code can carry two shapes depending on the authoring tool:
    #   (a) just the body, e.g. ``self.x = self.x + 1``
    #   (b) the full ``def`` block, e.g. ``def step(self, dt): ...``
    # The web modeling editor saves shape (b). We detect it at generation
    # time and emit at class scope; otherwise we wrap with a generated
    # def header so a bare body still becomes a callable method.

    def compute_output(self):
        """Sinusoidal daily power profile (hour 0–23, peak at 12).
        _sim_hour advances by 1 each tick (set it to 6 to start at dawn).
        Updates ratedPower [kW].
        """
        import math
        hour = float(getattr(self, '_sim_hour', 0)) % 24
        self._sim_hour = (hour + 1) % 24
        factor = max(0.0, math.sin(math.pi * hour / 12.0))
        self.ratedPower = round(float(self.peakPower or 0.0) * factor, 2)



class Valve:
    """
    Valve class from H2_Plant_Metamodel domain model.
    
    Attributes:
        status (EquipmentStatus): EquipmentStatus attribute        manufacturer (str): str attribute        valveType (str): str attribute        maxPressure (float): float attribute        name (str): str attribute        tag (str): str attribute        cv (float): float attribute        modelNumber (str): str attribute        opening (float): float attribute        installationDate (date): date attribute    """
    
    def __init__(self, status: Optional[Any] = None, manufacturer: Optional[str] = None, valveType: Optional[str] = None, maxPressure: Optional[float] = None, name: Optional[str] = None, tag: Optional[str] = None, cv: Optional[float] = None, modelNumber: Optional[str] = None, opening: Optional[float] = None, installationDate: Optional[date] = None):
        """Initialize Valve instance."""
        self.status = status
        self.manufacturer = manufacturer
        self.valveType = valveType
        self.maxPressure = maxPressure
        self.name = name
        self.tag = tag
        self.cv = cv
        self.modelNumber = modelNumber
        self.opening = opening
        self.installationDate = installationDate
        
        # Association references
        self.ports: List['Port'] = []
    
    def to_dict(self) -> dict:
        """Convert instance to dictionary."""
        return {
            "class_name": "Valve",
            "status": self.status,
            "manufacturer": self.manufacturer,
            "valveType": self.valveType,
            "maxPressure": self.maxPressure,
            "name": self.name,
            "tag": self.tag,
            "cv": self.cv,
            "modelNumber": self.modelNumber,
            "opening": self.opening,
            "installationDate": self.installationDate,
            "ports": [obj.to_dict() if hasattr(obj, 'to_dict') else str(obj) for obj in (self.ports if isinstance(self.ports, list) else [self.ports] if self.ports else [])],
        }

    def __repr__(self) -> str:
        return f"Valve(status={self.status!r}, manufacturer={self.manufacturer!r}, valveType={self.valveType!r}, maxPressure={self.maxPressure!r}, name={self.name!r}, tag={self.tag!r}, cv={self.cv!r}, modelNumber={self.modelNumber!r}, opening={self.opening!r}, installationDate={self.installationDate!r})"

    # ------------------------------------------------------------------
    # User-authored behaviour
    # ------------------------------------------------------------------
    # Methods are emitted from cls.methods. Phase 1.0 only executes bodies
    # whose implementation_type is CODE — others stub out and raise so the
    # gap is visible (instead of silently no-oping). Sorted by name for a
    # deterministic generated output.
    #
    # Method.code can carry two shapes depending on the authoring tool:
    #   (a) just the body, e.g. ``self.x = self.x + 1``
    #   (b) the full ``def`` block, e.g. ``def step(self, dt): ...``
    # The web modeling editor saves shape (b). We detect it at generation
    # time and emit at class scope; otherwise we wrap with a generated
    # def header so a bare body still becomes a callable method.

    def close(self):
        """close — no executable body (implementation_type=NONE)."""
        pass

    def open(self):
        """open — no executable body (implementation_type=NONE)."""
        pass


class StorageTank:
    """
    StorageTank class from H2_Plant_Metamodel domain model.
    
    Attributes:
        volume (float): float attribute        status (EquipmentStatus): EquipmentStatus attribute        manufacturer (str): str attribute        currentLevel (float): float attribute        maxPressure (float): float attribute        level (float): float attribute        material (str): str attribute        storagePhase (StreamPhase): StreamPhase attribute        name (str): str attribute        tag (str): str attribute        modelNumber (str): str attribute        currentPressure (float): float attribute        installationDate (date): date attribute    """
    
    def __init__(self, volume: Optional[float] = None, status: Optional[Any] = None, manufacturer: Optional[str] = None, currentLevel: Optional[float] = None, maxPressure: Optional[float] = None, level: Optional[float] = None, material: Optional[str] = None, storagePhase: Optional[Any] = None, name: Optional[str] = None, tag: Optional[str] = None, modelNumber: Optional[str] = None, currentPressure: Optional[float] = None, installationDate: Optional[date] = None):
        """Initialize StorageTank instance."""
        self.volume = volume
        self.status = status
        self.manufacturer = manufacturer
        self.currentLevel = currentLevel
        self.maxPressure = maxPressure
        self.level = level
        self.material = material
        self.storagePhase = storagePhase
        self.name = name
        self.tag = tag
        self.modelNumber = modelNumber
        self.currentPressure = currentPressure
        self.installationDate = installationDate
        
        # Association references
        self.ports: List['Port'] = []
    
    def to_dict(self) -> dict:
        """Convert instance to dictionary."""
        return {
            "class_name": "StorageTank",
            "volume": self.volume,
            "status": self.status,
            "manufacturer": self.manufacturer,
            "currentLevel": self.currentLevel,
            "maxPressure": self.maxPressure,
            "level": self.level,
            "material": self.material,
            "storagePhase": self.storagePhase,
            "name": self.name,
            "tag": self.tag,
            "modelNumber": self.modelNumber,
            "currentPressure": self.currentPressure,
            "installationDate": self.installationDate,
            "ports": [obj.to_dict() if hasattr(obj, 'to_dict') else str(obj) for obj in (self.ports if isinstance(self.ports, list) else [self.ports] if self.ports else [])],
        }

    def __repr__(self) -> str:
        return f"StorageTank(volume={self.volume!r}, status={self.status!r}, manufacturer={self.manufacturer!r}, currentLevel={self.currentLevel!r}, maxPressure={self.maxPressure!r}, level={self.level!r}, material={self.material!r}, storagePhase={self.storagePhase!r}, name={self.name!r}, tag={self.tag!r}, modelNumber={self.modelNumber!r}, currentPressure={self.currentPressure!r}, installationDate={self.installationDate!r})"

    # ------------------------------------------------------------------
    # User-authored behaviour
    # ------------------------------------------------------------------
    # Methods are emitted from cls.methods. Phase 1.0 only executes bodies
    # whose implementation_type is CODE — others stub out and raise so the
    # gap is visible (instead of silently no-oping). Sorted by name for a
    # deterministic generated output.
    #
    # Method.code can carry two shapes depending on the authoring tool:
    #   (a) just the body, e.g. ``self.x = self.x + 1``
    #   (b) the full ``def`` block, e.g. ``def step(self, dt): ...``
    # The web modeling editor saves shape (b). We detect it at generation
    # time and emit at class scope; otherwise we wrap with a generated
    # def header so a bare body still becomes a callable method.

    def update_tank_level(self):
        """Integrate inflow − outflow into level.

        Walks the topology to discover live flow:
        tank.ports
          → each port's direction filter
          → port.incomingStreams (Inlet) or port.outgoingStreams (Outlet)
          → stream.massFlow (kg/s)
        """
        inflow_kg_s = 0.0
        outflow_kg_s = 0.0
        for p in (self.ports or []):
            direction = str(getattr(p, 'direction', '')).strip().lower()
            if direction == 'inlet':
                for s in (p.incomingStreams or []):
                    inflow_kg_s += float(s.massFlow or 0.0)
            elif direction == 'outlet':
                for s in (p.outgoingStreams or []):
                    outflow_kg_s += float(s.massFlow or 0.0)
        delta_level = (inflow_kg_s - outflow_kg_s)
        self.level = max(0.0, min(100.0, (self.level or 0.0) + delta_level))



class Separator:
    """
    Separator class from H2_Plant_Metamodel domain model.
    
    Attributes:
        status (EquipmentStatus): EquipmentStatus attribute        separationEfficiency (float): float attribute        manufacturer (str): str attribute        name (str): str attribute        tag (str): str attribute        modelNumber (str): str attribute        recoveryRate (float): float attribute        installationDate (date): date attribute    """
    
    def __init__(self, status: Optional[Any] = None, separationEfficiency: Optional[float] = None, manufacturer: Optional[str] = None, name: Optional[str] = None, tag: Optional[str] = None, modelNumber: Optional[str] = None, recoveryRate: Optional[float] = None, installationDate: Optional[date] = None):
        """Initialize Separator instance."""
        self.status = status
        self.separationEfficiency = separationEfficiency
        self.manufacturer = manufacturer
        self.name = name
        self.tag = tag
        self.modelNumber = modelNumber
        self.recoveryRate = recoveryRate
        self.installationDate = installationDate
        
        # Association references
        self.ports: List['Port'] = []
    
    def to_dict(self) -> dict:
        """Convert instance to dictionary."""
        return {
            "class_name": "Separator",
            "status": self.status,
            "separationEfficiency": self.separationEfficiency,
            "manufacturer": self.manufacturer,
            "name": self.name,
            "tag": self.tag,
            "modelNumber": self.modelNumber,
            "recoveryRate": self.recoveryRate,
            "installationDate": self.installationDate,
            "ports": [obj.to_dict() if hasattr(obj, 'to_dict') else str(obj) for obj in (self.ports if isinstance(self.ports, list) else [self.ports] if self.ports else [])],
        }

    def __repr__(self) -> str:
        return f"Separator(status={self.status!r}, separationEfficiency={self.separationEfficiency!r}, manufacturer={self.manufacturer!r}, name={self.name!r}, tag={self.tag!r}, modelNumber={self.modelNumber!r}, recoveryRate={self.recoveryRate!r}, installationDate={self.installationDate!r})"

    # ------------------------------------------------------------------
    # User-authored behaviour
    # ------------------------------------------------------------------
    # Methods are emitted from cls.methods. Phase 1.0 only executes bodies
    # whose implementation_type is CODE — others stub out and raise so the
    # gap is visible (instead of silently no-oping). Sorted by name for a
    # deterministic generated output.
    #
    # Method.code can carry two shapes depending on the authoring tool:
    #   (a) just the body, e.g. ``self.x = self.x + 1``
    #   (b) the full ``def`` block, e.g. ``def step(self, dt): ...``
    # The web modeling editor saves shape (b). We detect it at generation
    # time and emit at class scope; otherwise we wrap with a generated
    # def header so a bare body still becomes a callable method.


class PSAUnit:
    """
    PSAUnit class from H2_Plant_Metamodel domain model.
    
    Attributes:
        adsorbentType (str): str attribute        workingPressure (float): float attribute        status (EquipmentStatus): EquipmentStatus attribute        manufacturer (str): str attribute        purgeRatio (float): float attribute        separationEfficiency (float): float attribute        name (str): str attribute        tag (str): str attribute        modelNumber (str): str attribute        recoveryRate (float): float attribute        cycleTime (float): float attribute        installationDate (date): date attribute    """
    
    def __init__(self, adsorbentType: Optional[str] = None, workingPressure: Optional[float] = None, status: Optional[Any] = None, manufacturer: Optional[str] = None, purgeRatio: Optional[float] = None, separationEfficiency: Optional[float] = None, name: Optional[str] = None, tag: Optional[str] = None, modelNumber: Optional[str] = None, recoveryRate: Optional[float] = None, cycleTime: Optional[float] = None, installationDate: Optional[date] = None):
        """Initialize PSAUnit instance."""
        self.adsorbentType = adsorbentType
        self.workingPressure = workingPressure
        self.status = status
        self.manufacturer = manufacturer
        self.purgeRatio = purgeRatio
        self.separationEfficiency = separationEfficiency
        self.name = name
        self.tag = tag
        self.modelNumber = modelNumber
        self.recoveryRate = recoveryRate
        self.cycleTime = cycleTime
        self.installationDate = installationDate
        
        # Association references
        self.ports: List['Port'] = []
    
    def to_dict(self) -> dict:
        """Convert instance to dictionary."""
        return {
            "class_name": "PSAUnit",
            "adsorbentType": self.adsorbentType,
            "workingPressure": self.workingPressure,
            "status": self.status,
            "manufacturer": self.manufacturer,
            "purgeRatio": self.purgeRatio,
            "separationEfficiency": self.separationEfficiency,
            "name": self.name,
            "tag": self.tag,
            "modelNumber": self.modelNumber,
            "recoveryRate": self.recoveryRate,
            "cycleTime": self.cycleTime,
            "installationDate": self.installationDate,
            "ports": [obj.to_dict() if hasattr(obj, 'to_dict') else str(obj) for obj in (self.ports if isinstance(self.ports, list) else [self.ports] if self.ports else [])],
        }

    def __repr__(self) -> str:
        return f"PSAUnit(adsorbentType={self.adsorbentType!r}, workingPressure={self.workingPressure!r}, status={self.status!r}, manufacturer={self.manufacturer!r}, purgeRatio={self.purgeRatio!r}, separationEfficiency={self.separationEfficiency!r}, name={self.name!r}, tag={self.tag!r}, modelNumber={self.modelNumber!r}, recoveryRate={self.recoveryRate!r}, cycleTime={self.cycleTime!r}, installationDate={self.installationDate!r})"

    # ------------------------------------------------------------------
    # User-authored behaviour
    # ------------------------------------------------------------------
    # Methods are emitted from cls.methods. Phase 1.0 only executes bodies
    # whose implementation_type is CODE — others stub out and raise so the
    # gap is visible (instead of silently no-oping). Sorted by name for a
    # deterministic generated output.
    #
    # Method.code can carry two shapes depending on the authoring tool:
    #   (a) just the body, e.g. ``self.x = self.x + 1``
    #   (b) the full ``def`` block, e.g. ``def step(self, dt): ...``
    # The web modeling editor saves shape (b). We detect it at generation
    # time and emit at class scope; otherwise we wrap with a generated
    # def header so a bare body still becomes a callable method.

    def purify(self):
        """Cycle PSA adsorption / regeneration phases.
        workingPressure oscillates to model the high-pressure adsorption
        and low-pressure purge strokes of the PSA bed.
        """
        wp         = float(self.workingPressure or 5.0)
        cycle_time = float(self.cycleTime or 60.0)   # s per half-cycle
        elapsed    = float(getattr(self, '_phase_t', 0.0))
        adsorbing  = (elapsed % (cycle_time * 2)) < cycle_time
        self.workingPressure = round(min(8.0, wp + 0.4) if adsorbing
                                     else max(1.0, wp - 0.4), 2)
        self._phase_t = elapsed + 1.0



class Dryer:
    """
    Dryer class from H2_Plant_Metamodel domain model.
    
    Attributes:
        moistureRemovalRate (float): float attribute        status (EquipmentStatus): EquipmentStatus attribute        manufacturer (str): str attribute        separationEfficiency (float): float attribute        name (str): str attribute        tag (str): str attribute        modelNumber (str): str attribute        recoveryRate (float): float attribute        dewPoint (float): float attribute        installationDate (date): date attribute    """
    
    def __init__(self, moistureRemovalRate: Optional[float] = None, status: Optional[Any] = None, manufacturer: Optional[str] = None, separationEfficiency: Optional[float] = None, name: Optional[str] = None, tag: Optional[str] = None, modelNumber: Optional[str] = None, recoveryRate: Optional[float] = None, dewPoint: Optional[float] = None, installationDate: Optional[date] = None):
        """Initialize Dryer instance."""
        self.moistureRemovalRate = moistureRemovalRate
        self.status = status
        self.manufacturer = manufacturer
        self.separationEfficiency = separationEfficiency
        self.name = name
        self.tag = tag
        self.modelNumber = modelNumber
        self.recoveryRate = recoveryRate
        self.dewPoint = dewPoint
        self.installationDate = installationDate
        
        # Association references
        self.ports: List['Port'] = []
    
    def to_dict(self) -> dict:
        """Convert instance to dictionary."""
        return {
            "class_name": "Dryer",
            "moistureRemovalRate": self.moistureRemovalRate,
            "status": self.status,
            "manufacturer": self.manufacturer,
            "separationEfficiency": self.separationEfficiency,
            "name": self.name,
            "tag": self.tag,
            "modelNumber": self.modelNumber,
            "recoveryRate": self.recoveryRate,
            "dewPoint": self.dewPoint,
            "installationDate": self.installationDate,
            "ports": [obj.to_dict() if hasattr(obj, 'to_dict') else str(obj) for obj in (self.ports if isinstance(self.ports, list) else [self.ports] if self.ports else [])],
        }

    def __repr__(self) -> str:
        return f"Dryer(moistureRemovalRate={self.moistureRemovalRate!r}, status={self.status!r}, manufacturer={self.manufacturer!r}, separationEfficiency={self.separationEfficiency!r}, name={self.name!r}, tag={self.tag!r}, modelNumber={self.modelNumber!r}, recoveryRate={self.recoveryRate!r}, dewPoint={self.dewPoint!r}, installationDate={self.installationDate!r})"

    # ------------------------------------------------------------------
    # User-authored behaviour
    # ------------------------------------------------------------------
    # Methods are emitted from cls.methods. Phase 1.0 only executes bodies
    # whose implementation_type is CODE — others stub out and raise so the
    # gap is visible (instead of silently no-oping). Sorted by name for a
    # deterministic generated output.
    #
    # Method.code can carry two shapes depending on the authoring tool:
    #   (a) just the body, e.g. ``self.x = self.x + 1``
    #   (b) the full ``def`` block, e.g. ``def step(self, dt): ...``
    # The web modeling editor saves shape (b). We detect it at generation
    # time and emit at class scope; otherwise we wrap with a generated
    # def header so a bare body still becomes a callable method.

    def dry(self):
        """Drive dew point toward the -60 C setpoint as the dryer warms up.
        First-order approach: closes 5 % of the remaining gap each tick.
        """
        dew    = float(self.dewPoint or -20.0)
        target = -60.0                        # typical dried H2 dew point [C]
        self.dewPoint = round(dew + (target - dew) * 0.05, 1)



class Pump:
    """
    Pump class from H2_Plant_Metamodel domain model.
    
    Attributes:
        installationDate (date): date attribute        status (EquipmentStatus): EquipmentStatus attribute        manufacturer (str): str attribute        flowRate (float): float attribute        head (float): float attribute        name (str): str attribute        tag (str): str attribute        modelNumber (str): str attribute        power (float): float attribute        efficiency (float): float attribute    """
    
    def __init__(self, installationDate: Optional[date] = None, status: Optional[Any] = None, manufacturer: Optional[str] = None, flowRate: Optional[float] = None, head: Optional[float] = None, name: Optional[str] = None, tag: Optional[str] = None, modelNumber: Optional[str] = None, power: Optional[float] = None, efficiency: Optional[float] = None):
        """Initialize Pump instance."""
        self.installationDate = installationDate
        self.status = status
        self.manufacturer = manufacturer
        self.flowRate = flowRate
        self.head = head
        self.name = name
        self.tag = tag
        self.modelNumber = modelNumber
        self.power = power
        self.efficiency = efficiency
        
        # Association references
        self.ports: List['Port'] = []
    
    def to_dict(self) -> dict:
        """Convert instance to dictionary."""
        return {
            "class_name": "Pump",
            "installationDate": self.installationDate,
            "status": self.status,
            "manufacturer": self.manufacturer,
            "flowRate": self.flowRate,
            "head": self.head,
            "name": self.name,
            "tag": self.tag,
            "modelNumber": self.modelNumber,
            "power": self.power,
            "efficiency": self.efficiency,
            "ports": [obj.to_dict() if hasattr(obj, 'to_dict') else str(obj) for obj in (self.ports if isinstance(self.ports, list) else [self.ports] if self.ports else [])],
        }

    def __repr__(self) -> str:
        return f"Pump(installationDate={self.installationDate!r}, status={self.status!r}, manufacturer={self.manufacturer!r}, flowRate={self.flowRate!r}, head={self.head!r}, name={self.name!r}, tag={self.tag!r}, modelNumber={self.modelNumber!r}, power={self.power!r}, efficiency={self.efficiency!r})"

    # ------------------------------------------------------------------
    # User-authored behaviour
    # ------------------------------------------------------------------
    # Methods are emitted from cls.methods. Phase 1.0 only executes bodies
    # whose implementation_type is CODE — others stub out and raise so the
    # gap is visible (instead of silently no-oping). Sorted by name for a
    # deterministic generated output.
    #
    # Method.code can carry two shapes depending on the authoring tool:
    #   (a) just the body, e.g. ``self.x = self.x + 1``
    #   (b) the full ``def`` block, e.g. ``def step(self, dt): ...``
    # The web modeling editor saves shape (b). We detect it at generation
    # time and emit at class scope; otherwise we wrap with a generated
    # def header so a bare body still becomes a callable method.


class Compressor:
    """
    Compressor class from H2_Plant_Metamodel domain model.
    
    Attributes:
        inletPressure (float): float attribute        stages (int): int attribute        status (EquipmentStatus): EquipmentStatus attribute        manufacturer (str): str attribute        outletPressure (float): float attribute        name (str): str attribute        compressionRatio (float): float attribute        tag (str): str attribute        power (float): float attribute        modelNumber (str): str attribute        isentropicEfficiency (float): float attribute        installationDate (date): date attribute    """
    
    def __init__(self, inletPressure: Optional[float] = None, stages: Optional[int] = None, status: Optional[Any] = None, manufacturer: Optional[str] = None, outletPressure: Optional[float] = None, name: Optional[str] = None, compressionRatio: Optional[float] = None, tag: Optional[str] = None, power: Optional[float] = None, modelNumber: Optional[str] = None, isentropicEfficiency: Optional[float] = None, installationDate: Optional[date] = None):
        """Initialize Compressor instance."""
        self.inletPressure = inletPressure
        self.stages = stages
        self.status = status
        self.manufacturer = manufacturer
        self.outletPressure = outletPressure
        self.name = name
        self.compressionRatio = compressionRatio
        self.tag = tag
        self.power = power
        self.modelNumber = modelNumber
        self.isentropicEfficiency = isentropicEfficiency
        self.installationDate = installationDate
        
        # Association references
        self.ports: List['Port'] = []
    
    def to_dict(self) -> dict:
        """Convert instance to dictionary."""
        return {
            "class_name": "Compressor",
            "inletPressure": self.inletPressure,
            "stages": self.stages,
            "status": self.status,
            "manufacturer": self.manufacturer,
            "outletPressure": self.outletPressure,
            "name": self.name,
            "compressionRatio": self.compressionRatio,
            "tag": self.tag,
            "power": self.power,
            "modelNumber": self.modelNumber,
            "isentropicEfficiency": self.isentropicEfficiency,
            "installationDate": self.installationDate,
            "ports": [obj.to_dict() if hasattr(obj, 'to_dict') else str(obj) for obj in (self.ports if isinstance(self.ports, list) else [self.ports] if self.ports else [])],
        }

    def __repr__(self) -> str:
        return f"Compressor(inletPressure={self.inletPressure!r}, stages={self.stages!r}, status={self.status!r}, manufacturer={self.manufacturer!r}, outletPressure={self.outletPressure!r}, name={self.name!r}, compressionRatio={self.compressionRatio!r}, tag={self.tag!r}, power={self.power!r}, modelNumber={self.modelNumber!r}, isentropicEfficiency={self.isentropicEfficiency!r}, installationDate={self.installationDate!r})"

    # ------------------------------------------------------------------
    # User-authored behaviour
    # ------------------------------------------------------------------
    # Methods are emitted from cls.methods. Phase 1.0 only executes bodies
    # whose implementation_type is CODE — others stub out and raise so the
    # gap is visible (instead of silently no-oping). Sorted by name for a
    # deterministic generated output.
    #
    # Method.code can carry two shapes depending on the authoring tool:
    #   (a) just the body, e.g. ``self.x = self.x + 1``
    #   (b) the full ``def`` block, e.g. ``def step(self, dt): ...``
    # The web modeling editor saves shape (b). We detect it at generation
    # time and emit at class scope; otherwise we wrap with a generated
    # def header so a bare body still becomes a callable method.

    def compress(self):
        """Compute outlet pressure and shaft power from inlet conditions."""
        import math
        ratio  = float(self.compressionRatio or 2.5)
        p_in   = float(self.inletPressure or 30.0)     # bar
        eff    = float(self.isentropicEfficiency or 0.75)
        stages = int(self.stages or 1)
        # Per-stage ratio for multi-stage compression
        stage_ratio = ratio ** (1.0 / max(1, stages))
        self.outletPressure = round(p_in * (stage_ratio ** stages), 1)
        # Simplified isothermal shaft power [kW]
        self.power = round(p_in * 1e2 * math.log(max(1.0001, ratio)) / max(0.01, eff), 2)


