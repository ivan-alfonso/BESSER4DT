"""
Export Router

Handles exporting instances to various formats (JSON, Python code) and
importing previously exported JSON payloads back into the live platform
(round-trip persistence — see /import/json).
"""

from typing import Any, Dict

from fastapi import APIRouter, Body, HTTPException, Response
from fastapi.responses import FileResponse, JSONResponse
from services.export_service import export_service
import tempfile
import os

router = APIRouter()


@router.get("/json")
async def export_as_json():
    """Export all instances as JSON."""
    try:
        json_data = export_service.export_to_json()
        return JSONResponse(content=json_data)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/python")
async def export_as_python():
    """Export all instances as Python code."""
    try:
        python_code = export_service.export_to_python()
        return Response(
            content=python_code,
            media_type="text/plain",
            headers={"Content-Disposition": "attachment; filename=instances.py"}
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/buml")
async def export_as_buml():
    """Export all instances as BUML object model code."""
    try:
        buml_code = export_service.export_to_buml()
        return Response(
            content=buml_code,
            media_type="text/plain",
            headers={"Content-Disposition": "attachment; filename=object_model.py"}
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/import/json")
async def import_as_json(payload: Dict[str, Any] = Body(...), replace: bool = True):
    """Load a previously exported JSON payload back into the live store.

    Accepts the same shape returned by ``GET /export/json``. ``replace=True``
    (default) wipes existing state before loading — "Load Plant" semantics.
    Returns counts of instances and links restored.
    """
    try:
        counts = export_service.import_from_json(payload, replace=replace)
        return JSONResponse(content={"success": True, **counts})
    except ValueError as e:
        # Validation failures (unknown class, bad shape) are user errors.
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))