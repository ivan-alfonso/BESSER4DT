"""Generated platform bootstrap for the besser4DT runtime kernel.

Wires the generic Engine, Scheduler, InputBindings, and HistoryStore
to this platform's singleton ``services.instance_manager`` and to
the per-domain ``ASSOCIATION_ENDS`` table.
"""
from services.instance_manager import instance_manager

from .associations import ASSOCIATION_ENDS
from .bindings import InputBindings
from .engine import Engine
from .history import HistoryStore
from .materialize import AssociationEndMeta, AssociationsIndex, materialize_classes
from .scheduler import Scheduler

_by_end = {}
_by_assoc = {}
for _entry in ASSOCIATION_ENDS:
    _meta = AssociationEndMeta(**_entry)
    if _meta.end_name:
        _by_end[(_meta.owner_class, _meta.end_name)] = _meta
    if _meta.association_name:
        _by_assoc[(_meta.owner_class, _meta.association_name)] = _meta
_associations_index = AssociationsIndex(by_end=_by_end, by_assoc=_by_assoc)

engine = Engine(
    instance_manager=instance_manager,
    class_map=instance_manager.class_map,
    associations_index=_associations_index,
)

_steppable_classes = {'PSAUnit': 'purify', 'WindFarm': 'compute_output', 'SolarFarm': 'compute_output', 'StorageTank': 'update_tank_level', 'Dryer': 'dry', 'Compressor': 'compress', 'Truck': 'deliver', 'H2DeliveryPoint': 'dispense_h2', 'Electrolyzer': 'produce_h2'}

history = HistoryStore(instance_manager=instance_manager, steppable_classes=None)
bindings = InputBindings(instance_manager=instance_manager)
scheduler = Scheduler(
    engine=engine,
    history=history,
    bindings=bindings,
    instance_manager=instance_manager,
    steppable_classes=_steppable_classes,
    dt=1.0,
)

# Restore persisted bindings if they exist from a previous run.
bindings.load("dt_bindings.json")

__all__ = ["Engine", "engine", "materialize_classes",
           "Scheduler", "scheduler", "InputBindings", "bindings",
           "HistoryStore", "history",
           "AssociationsIndex", "AssociationEndMeta"]
