"""Per-class association-end metadata, generated from the
source DomainModel. Drives runtime link resolution in the
Engine (multiplicity-aware slot assignment + reverse-index
bidirectional navigation).
"""
ASSOCIATION_ENDS = [
    {'owner_class': 'Pump', 'end_name': 'ports', 'target_class': 'Port', 'multiplicity_max': 9999, 'association_name': 'equi_ports'},
    {'owner_class': 'MaterialStream', 'end_name': 'sourcePort', 'target_class': 'Port', 'multiplicity_max': 1, 'association_name': 'source'},
    {'owner_class': 'MaterialStream', 'end_name': 'targetPort', 'target_class': 'Port', 'multiplicity_max': 1, 'association_name': 'target'},
    {'owner_class': 'AlkalineElectrolyzer', 'end_name': 'ports', 'target_class': 'Port', 'multiplicity_max': 9999, 'association_name': 'equi_ports'},
    {'owner_class': 'PSAUnit', 'end_name': 'ports', 'target_class': 'Port', 'multiplicity_max': 9999, 'association_name': 'equi_ports'},
    {'owner_class': 'Stream', 'end_name': 'sourcePort', 'target_class': 'Port', 'multiplicity_max': 1, 'association_name': 'source'},
    {'owner_class': 'Stream', 'end_name': 'targetPort', 'target_class': 'Port', 'multiplicity_max': 1, 'association_name': 'target'},
    {'owner_class': 'WindFarm', 'end_name': 'ports', 'target_class': 'Port', 'multiplicity_max': 9999, 'association_name': 'equi_ports'},
    {'owner_class': 'Port', 'end_name': 'equipment', 'target_class': 'Equipment', 'multiplicity_max': 1, 'association_name': 'equi_ports'},
    {'owner_class': 'Port', 'end_name': 'incomingStreams', 'target_class': 'Stream', 'multiplicity_max': 9999, 'association_name': 'target'},
    {'owner_class': 'Port', 'end_name': 'outgoingStreams', 'target_class': 'Stream', 'multiplicity_max': 9999, 'association_name': 'source'},
    {'owner_class': 'SolarFarm', 'end_name': 'ports', 'target_class': 'Port', 'multiplicity_max': 9999, 'association_name': 'equi_ports'},
    {'owner_class': 'EnergyStream', 'end_name': 'sourcePort', 'target_class': 'Port', 'multiplicity_max': 1, 'association_name': 'source'},
    {'owner_class': 'EnergyStream', 'end_name': 'targetPort', 'target_class': 'Port', 'multiplicity_max': 1, 'association_name': 'target'},
    {'owner_class': 'PEMElectrolyzer', 'end_name': 'ports', 'target_class': 'Port', 'multiplicity_max': 9999, 'association_name': 'equi_ports'},
    {'owner_class': 'StorageTank', 'end_name': 'ports', 'target_class': 'Port', 'multiplicity_max': 9999, 'association_name': 'equi_ports'},
    {'owner_class': 'Dryer', 'end_name': 'ports', 'target_class': 'Port', 'multiplicity_max': 9999, 'association_name': 'equi_ports'},
    {'owner_class': 'Valve', 'end_name': 'ports', 'target_class': 'Port', 'multiplicity_max': 9999, 'association_name': 'equi_ports'},
    {'owner_class': 'PowerSource', 'end_name': 'ports', 'target_class': 'Port', 'multiplicity_max': 9999, 'association_name': 'equi_ports'},
    {'owner_class': 'Separator', 'end_name': 'ports', 'target_class': 'Port', 'multiplicity_max': 9999, 'association_name': 'equi_ports'},
    {'owner_class': 'Compressor', 'end_name': 'ports', 'target_class': 'Port', 'multiplicity_max': 9999, 'association_name': 'equi_ports'},
    {'owner_class': 'GridConnection', 'end_name': 'ports', 'target_class': 'Port', 'multiplicity_max': 9999, 'association_name': 'equi_ports'},
    {'owner_class': 'Truck', 'end_name': 'ports', 'target_class': 'Port', 'multiplicity_max': 9999, 'association_name': 'equi_ports'},
    {'owner_class': 'TransportUnit', 'end_name': 'ports', 'target_class': 'Port', 'multiplicity_max': 9999, 'association_name': 'equi_ports'},
    {'owner_class': 'Equipment', 'end_name': 'ports', 'target_class': 'Port', 'multiplicity_max': 9999, 'association_name': 'equi_ports'},
    {'owner_class': 'H2DeliveryPoint', 'end_name': 'ports', 'target_class': 'Port', 'multiplicity_max': 9999, 'association_name': 'equi_ports'},
    {'owner_class': 'UnitOperation', 'end_name': 'ports', 'target_class': 'Port', 'multiplicity_max': 9999, 'association_name': 'equi_ports'},
    {'owner_class': 'Electrolyzer', 'end_name': 'ports', 'target_class': 'Port', 'multiplicity_max': 9999, 'association_name': 'equi_ports'},
    {'owner_class': 'SOECElectrolyzer', 'end_name': 'ports', 'target_class': 'Port', 'multiplicity_max': 9999, 'association_name': 'equi_ports'},
]
