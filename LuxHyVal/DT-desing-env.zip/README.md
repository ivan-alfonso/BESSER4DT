# H2_Plant_Metamodel Instance Editor

Auto-generated instance editor platform for the H2_Plant_Metamodel domain model.

## Overview

This is a full-stack web application that allows you to create and manage instances of the classes defined in your H2_Plant_Metamodel domain model. The application provides:

- **Visual Instance Editor**: Drag-and-drop canvas for creating instances
- **Property Editor**: Edit instance attributes in a side panel
- **Association Links**: Create relationships between instances
- **Export Capabilities**: Export your instance model as JSON or Python code
- **REST API**: Full CRUD API for programmatic access

## Architecture

- **Backend**: FastAPI (Python 3.11+)
- **Frontend**: React 18 + TypeScript + ReactFlow
- **Deployment**: Docker + Docker Compose

## Quick Start

### Using Docker (Recommended)

1. **Start the application**:
   ```bash
   docker-compose up --build
   ```

2. **Access the application**:
   - Frontend: http://localhost:3000
   - Backend API: http://localhost:8000
   - API Docs: http://localhost:8000/docs

### Manual Setup

#### Backend

```bash
cd backend
pip install -r requirements.txt
uvicorn main:app --reload
```

#### Frontend

```bash
cd frontend
npm install
npm run dev
```

## Available Classes

The following classes are available in the H2_Plant_Metamodel domain model:

- **Pump**  - Attributes:    - `installationDate` (date)    - `status` (EquipmentStatus)    - `manufacturer` (str)    - `flowRate` (float)    - `head` (float)    - `name` (str)    - `tag` (str)    - `modelNumber` (str)    - `power` (float)    - `efficiency` (float)  - Associations:    - `ports` → Port [0..*]- **MaterialStream**  - Attributes:    - `temperature` (float)    - `enthalpy` (float)    - `name` (str)    - `phase` (StreamPhase)    - `massFlow` (float)    - `density` (float)    - `tag` (str)    - `pressure` (float)    - `vaporFraction` (float)    - `molarFlow` (float)  - Associations:    - `sourcePort` → Port [1..1]    - `targetPort` → Port [1..1]- **AlkalineElectrolyzer**  - Attributes:    - `status` (EquipmentStatus)    - `operatingTemperature` (float)    - `nominalPower` (float)    - `stackVoltage` (float)    - `operatingPressure` (float)    - `bubblePoint` (float)    - `modelNumber` (str)    - `electrolyteConcentration` (float)    - `installationDate` (date)    - `manufacturer` (str)    - `maxLoad` (float)    - `name` (str)    - `tag` (str)    - `nominalH2Production` (float)    - `stackCurrent` (float)    - `minLoad` (float)    - `specificEnergyConsumption` (float)  - Associations:    - `ports` → Port [0..*]- **PSAUnit**  - Attributes:    - `adsorbentType` (str)    - `workingPressure` (float)    - `status` (EquipmentStatus)    - `manufacturer` (str)    - `purgeRatio` (float)    - `separationEfficiency` (float)    - `name` (str)    - `tag` (str)    - `modelNumber` (str)    - `recoveryRate` (float)    - `cycleTime` (float)    - `installationDate` (date)  - Associations:    - `ports` → Port [0..*]- **Stream**  - Attributes:    - `tag` (str)    - `name` (str)  - Associations:    - `sourcePort` → Port [1..1]    - `targetPort` → Port [1..1]- **WindFarm**  - Attributes:    - `ratedWindSpeed` (float)    - `status` (EquipmentStatus)    - `manufacturer` (str)    - `ratedPower` (float)    - `currentPower` (float)    - `turbineCount` (int)    - `hubHeight` (float)    - `name` (str)    - `tag` (str)    - `modelNumber` (str)    - `availability` (float)    - `installationDate` (date)  - Associations:    - `ports` → Port [0..*]- **Port**  - Attributes:    - `direction` (PortDirection)    - `designPressure` (float)    - `name` (str)    - `designTemperature` (float)  - Associations:    - `equipment` → Equipment [1..1]    - `incomingStreams` → Stream [0..*]    - `outgoingStreams` → Stream [0..*]- **SolarFarm**  - Attributes:    - `installationDate` (date)    - `status` (EquipmentStatus)    - `manufacturer` (str)    - `ratedPower` (float)    - `area` (float)    - `name` (str)    - `tag` (str)    - `modelNumber` (str)    - `availability` (float)    - `panelCount` (int)    - `peakPower` (float)  - Associations:    - `ports` → Port [0..*]- **EnergyStream**  - Attributes:    - `energyType` (str)    - `frequency` (float)    - `name` (str)    - `voltage` (float)    - `power` (float)    - `tag` (str)  - Associations:    - `sourcePort` → Port [1..1]    - `targetPort` → Port [1..1]- **PEMElectrolyzer**  - Attributes:    - `membraneArea` (float)    - `status` (EquipmentStatus)    - `operatingTemperature` (float)    - `nominalPower` (float)    - `membraneThickness` (float)    - `stackVoltage` (float)    - `operatingPressure` (float)    - `modelNumber` (str)    - `installationDate` (date)    - `manufacturer` (str)    - `maxLoad` (float)    - `name` (str)    - `tag` (str)    - `nominalH2Production` (float)    - `stackCurrent` (float)    - `minLoad` (float)    - `specificEnergyConsumption` (float)  - Associations:    - `ports` → Port [0..*]- **StorageTank**  - Attributes:    - `volume` (float)    - `status` (EquipmentStatus)    - `manufacturer` (str)    - `currentLevel` (float)    - `maxPressure` (float)    - `level` (float)    - `material` (str)    - `storagePhase` (StreamPhase)    - `name` (str)    - `tag` (str)    - `modelNumber` (str)    - `currentPressure` (float)    - `installationDate` (date)  - Associations:    - `ports` → Port [0..*]- **Dryer**  - Attributes:    - `moistureRemovalRate` (float)    - `status` (EquipmentStatus)    - `manufacturer` (str)    - `separationEfficiency` (float)    - `name` (str)    - `tag` (str)    - `modelNumber` (str)    - `recoveryRate` (float)    - `dewPoint` (float)    - `installationDate` (date)  - Associations:    - `ports` → Port [0..*]- **Valve**  - Attributes:    - `status` (EquipmentStatus)    - `manufacturer` (str)    - `valveType` (str)    - `maxPressure` (float)    - `name` (str)    - `tag` (str)    - `cv` (float)    - `modelNumber` (str)    - `opening` (float)    - `installationDate` (date)  - Associations:    - `ports` → Port [0..*]- **PowerSource**  - Attributes:    - `status` (EquipmentStatus)    - `manufacturer` (str)    - `ratedPower` (float)    - `name` (str)    - `tag` (str)    - `modelNumber` (str)    - `availability` (float)    - `installationDate` (date)  - Associations:    - `ports` → Port [0..*]- **Separator**  - Attributes:    - `status` (EquipmentStatus)    - `separationEfficiency` (float)    - `manufacturer` (str)    - `name` (str)    - `tag` (str)    - `modelNumber` (str)    - `recoveryRate` (float)    - `installationDate` (date)  - Associations:    - `ports` → Port [0..*]- **Compressor**  - Attributes:    - `inletPressure` (float)    - `stages` (int)    - `status` (EquipmentStatus)    - `manufacturer` (str)    - `outletPressure` (float)    - `name` (str)    - `compressionRatio` (float)    - `tag` (str)    - `power` (float)    - `modelNumber` (str)    - `isentropicEfficiency` (float)    - `installationDate` (date)  - Associations:    - `ports` → Port [0..*]- **GridConnection**  - Attributes:    - `frequency` (float)    - `status` (EquipmentStatus)    - `manufacturer` (str)    - `ratedPower` (float)    - `voltage` (float)    - `maxPower` (float)    - `name` (str)    - `tag` (str)    - `modelNumber` (str)    - `availability` (float)    - `installationDate` (date)  - Associations:    - `ports` → Port [0..*]- **Truck**  - Attributes:    - `attribute` (str)    - `status` (EquipmentStatus)    - `manufacturer` (str)    - `name` (str)    - `tag` (str)    - `currentLoad` (float)    - `modelNumber` (str)    - `capacity` (float)    - `installationDate` (date)  - Associations:    - `ports` → Port [0..*]- **TransportUnit**  - Attributes:    - `attribute` (str)    - `name` (str)    - `status` (EquipmentStatus)    - `manufacturer` (str)    - `tag` (str)    - `modelNumber` (str)    - `installationDate` (date)  - Associations:    - `ports` → Port [0..*]- **Equipment**  - Attributes:    - `name` (str)    - `status` (EquipmentStatus)    - `manufacturer` (str)    - `tag` (str)    - `modelNumber` (str)    - `installationDate` (date)  - Associations:    - `ports` → Port [0..*]- **H2DeliveryPoint**  - Attributes:    - `attribute` (str)    - `dispensingRate` (float)    - `status` (EquipmentStatus)    - `manufacturer` (str)    - `dispensingPressure` (float)    - `name` (str)    - `tag` (str)    - `modelNumber` (str)    - `tankCapacity` (float)    - `currentLevel` (float)    - `installationDate` (date)  - Associations:    - `ports` → Port [0..*]- **UnitOperation**  - Attributes:    - `name` (str)    - `status` (EquipmentStatus)    - `manufacturer` (str)    - `tag` (str)    - `modelNumber` (str)    - `installationDate` (date)  - Associations:    - `ports` → Port [0..*]- **Electrolyzer**  - Attributes:    - `installationDate` (date)    - `operatingTemperature` (float)    - `status` (EquipmentStatus)    - `manufacturer` (str)    - `nominalPower` (float)    - `maxLoad` (float)    - `stackVoltage` (float)    - `operatingPressure` (float)    - `name` (str)    - `tag` (str)    - `nominalH2Production` (float)    - `modelNumber` (str)    - `stackCurrent` (float)    - `minLoad` (float)    - `specificEnergyConsumption` (float)  - Associations:    - `ports` → Port [0..*]- **SOECElectrolyzer**  - Attributes:    - `status` (EquipmentStatus)    - `operatingTemperature` (float)    - `nominalPower` (float)    - `stackVoltage` (float)    - `operatingPressure` (float)    - `modelNumber` (str)    - `installationDate` (date)    - `manufacturer` (str)    - `maxLoad` (float)    - `ceramicMaterial` (str)    - `operatingTempSOEC` (float)    - `name` (str)    - `tag` (str)    - `nominalH2Production` (float)    - `stackCurrent` (float)    - `minLoad` (float)    - `specificEnergyConsumption` (float)  - Associations:    - `ports` → Port [0..*]
## Usage Guide

### Creating Instances

1. Click on a class in the left palette
2. Fill in the instance name and attributes
3. Click "Create"
4. The instance appears on the canvas

### Editing Instances

1. Click the "Edit" button on any instance
2. Modify attributes in the right panel
3. Click "Save"

### Creating Links (Associations)

1. Drag from the bottom handle of one instance
2. Drop on the top handle of another instance
3. Enter the association name when prompted

### Exporting

- **JSON Export**: Exports all instances and their links in JSON format
- **Python Export**: Generates Python code to recreate the instances
- **BUML Export**: Generates BUML Object Model code

## API Endpoints

### Instances

- `POST /api/instances/` - Create instance
- `GET /api/instances/` - Get all instances
- `GET /api/instances/{class_name}` - Get instances by class
- `GET /api/instances/{class_name}/{instance_id}` - Get specific instance
- `PUT /api/instances/{class_name}/{instance_id}` - Update instance
- `DELETE /api/instances/{class_name}/{instance_id}` - Delete instance

### Links

- `POST /api/instances/links` - Create link
- `DELETE /api/instances/links` - Delete link

### Export

- `GET /api/export/json` - Export as JSON
- `GET /api/export/python` - Export as Python code
- `GET /api/export/buml` - Export as BUML code

## Development

### Project Structure

```
.
├── backend/
│   ├── main.py                    # FastAPI application
│   ├── models/
│   │   └── domain_classes.py      # Domain model classes
│   ├── routers/
│   │   ├── instances.py           # Instance CRUD endpoints
│   │   └── export.py              # Export endpoints
│   ├── services/
│   │   ├── instance_manager.py    # Instance management logic
│   │   └── export_service.py      # Export logic
│   ├── schemas/
│   │   └── instance_schemas.py    # Pydantic schemas
│   └── requirements.txt
├── frontend/
│   ├── src/
│   │   ├── App.tsx                # Main application
│   │   ├── components/
│   │   │   ├── InstanceCanvas.tsx  # Canvas editor
│   │   │   ├── InstanceNode.tsx    # Instance visualization
│   │   │   ├── PropertyEditor.tsx  # Property editor panel
│   │   │   └── ClassPalette.tsx    # Class palette
│   │   ├── api/
│   │   │   ├── client.ts          # API client configuration
│   │   │   └── instances.ts       # Instance API calls
│   │   └── types/
│   │       └── models.ts          # TypeScript types
│   ├── package.json
│   └── vite.config.ts
└── docker-compose.yml
```

### Technology Stack

**Backend:**
- FastAPI 0.115+
- Pydantic 2.9+
- Uvicorn
- Python 3.11+

**Frontend:**
- React 18
- TypeScript 5
- ReactFlow 11
- Axios
- Vite
- TanStack Query

## Generated by BESSER

This platform was automatically generated by the [BESSER Platform Generator](https://github.com/BESSER-PEARL/BESSER).

BESSER (Building Better Smart Software Faster) is a low-code platform for model-driven software engineering.

## License

This generated code is provided as-is. You are free to modify and use it as needed.